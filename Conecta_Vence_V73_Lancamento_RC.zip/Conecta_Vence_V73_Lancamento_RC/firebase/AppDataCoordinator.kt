package com.conectaevencer.data

/**
 * V29 — Coordenador das ações da interface com a camada de dados.
 * As telas chamam estes métodos; operações financeiras reais continuam
 * dependendo da validação do backend.
 */
class AppDataCoordinator(
    private val wallet: CloudWalletRepository,
    private val history: FirestoreUserRepository
) {
    fun harvestBeans(amount: Long, onDone: (Boolean, String?) -> Unit) {
        wallet.recordMovement("feijões", "Colheita", amount, onDone)
    }

    fun convertBeansToDiamonds(
        beansUsed: Long,
        diamondsReceived: Long,
        onDone: (Boolean, String?) -> Unit
    ) {
        wallet.recordMovement(
            "conversão",
            "$beansUsed feijões → $diamondsReceived diamantes",
            diamondsReceived,
            onDone
        )
    }

    fun sendGift(
        giftName: String,
        diamondsUsed: Long,
        onDone: (Boolean, String?) -> Unit
    ) {
        wallet.recordMovement(
            "presente",
            "$giftName — $diamondsUsed diamantes",
            diamondsUsed,
            onDone
        )
    }

    fun updateGoal(
        goalName: String,
        progress: Long,
        onDone: (Boolean, String?) -> Unit
    ) {
        wallet.recordMovement(
            "meta",
            "$goalName — progresso +$progress",
            progress,
            onDone
        )
    }
}
