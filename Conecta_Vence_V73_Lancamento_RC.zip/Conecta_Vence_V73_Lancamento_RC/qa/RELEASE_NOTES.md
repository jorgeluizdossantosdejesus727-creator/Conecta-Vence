# Conecta & Vence — V35

Objetivo: preparar o projeto para a primeira rodada de teste fechado.

A publicação real depende das contas e credenciais reais do proprietário:
Google Play Console, Firebase, backend e assinatura do aplicativo.

Critério de saída:
o V35 só deve ser considerado pronto para teste fechado depois que o AAB
release for gerado, enviado à Play Console e os fluxos principais forem
validados pelos testers.
