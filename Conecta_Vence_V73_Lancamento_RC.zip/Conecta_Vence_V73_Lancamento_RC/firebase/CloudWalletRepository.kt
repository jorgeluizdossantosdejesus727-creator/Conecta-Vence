package com.conectaevencer.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.SetOptions

class CloudWalletRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private fun userRef() =
        db.collection("users").document(
            auth.currentUser?.uid ?: throw IllegalStateException("Usuário não autenticado")
        )

    fun saveWallet(
        beans: Long,
        diamonds: Long,
        giftsSent: Long,
        earningsCents: Long,
        onResult: (Boolean, String?) -> Unit
    ) {
        userRef().set(
            mapOf(
                "beans" to beans,
                "diamonds" to diamonds,
                "giftsSent" to giftsSent,
                "earningsCents" to earningsCents,
                "updatedAt" to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        ).addOnSuccessListener {
            onResult(true, null)
        }.addOnFailureListener {
            onResult(false, it.message)
        }
    }

    fun recordMovement(
        type: String,
        detail: String,
        amount: Long,
        onResult: (Boolean, String?) -> Unit
    ) {
        userRef().collection("history").add(
            mapOf(
                "type" to type,
                "detail" to detail,
                "amount" to amount,
                "createdAt" to FieldValue.serverTimestamp()
            )
        ).addOnSuccessListener {
            onResult(true, null)
        }.addOnFailureListener {
            onResult(false, it.message)
        }
    }
}
