# V38 — Configuração de produção

## Valores que precisam ser definidos no projeto real

- applicationId: `DEFINIR_NO_PROJETO`
- versionCode: `DEFINIR`
- versionName: `DEFINIR`
- Firebase project: `PROJETO_FIREBASE_REAL`
- API base URL: `ENDPOINT_BACKEND_REAL`

## Antes do build
1. Substituir os placeholders pelos valores reais.
2. Colocar o `google-services.json` correto no módulo `app`.
3. Configurar a assinatura release no ambiente seguro.
4. Conferir regras do Firestore.
5. Conferir o backend de compras, ganhos e saques.
6. Fazer build de release.
7. Testar o AAB antes da publicação.

Não coloque senhas, tokens privados ou a chave de assinatura dentro deste
arquivo ou do repositório.
