# Conecta & Vence V80

Versão com tela realmente em tela cheia, removendo horário, Wi‑Fi, sinal, bateria e barra de navegação do sistema durante o uso do aplicativo.

## Correções
- Tela cheia imersiva.
- Sem relógio, Wi‑Fi, sinal ou bateria sobre o aplicativo.
- Navegação inferior continua funcionando.
- Mantém as telas Início, Ao vivo, Conversas, Fazenda e Perfil.
- Mantém Entrar e Criar conta.

Esta versão é para teste do protótipo.
