# V29 — Telas integradas à camada de dados

A V29 define a ponte entre as ações da interface e o Firestore.

Mapeamento:
- Fazenda → `harvestBeans()`
- Conversão → `convertBeansToDiamonds()`
- Presentes → `sendGift()`
- Metas → `updateGoal()`
- Histórico → coleção `users/{uid}/history`

IMPORTANTE:
Esta camada registra as ações, mas não transforma o aplicativo em um sistema
financeiro pronto para produção. Saldos de dinheiro/moedas compradas devem
ser autorizados pelo backend após validação do pagamento.

Para concluir a integração:
1. ligar cada botão/tela aos métodos;
2. carregar os dados ao abrir as telas;
3. mostrar erros de rede;
4. sincronizar a carteira após cada operação;
5. testar offline/online;
6. configurar Firebase real.
