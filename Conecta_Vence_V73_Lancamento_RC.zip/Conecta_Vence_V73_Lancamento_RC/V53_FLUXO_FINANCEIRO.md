# V53 — Ciclo financeiro completo

1. Usuário compra um pacote no Google Play.
2. O Android recebe o `purchaseToken`.
3. O app envia o token ao backend.
4. O backend consulta a Google Play Developer API.
5. Se a compra não estiver `PURCHASED`, nenhuma moeda é liberada.
6. Se estiver válida, uma transação atômica:
   - cria/atualiza a compra;
   - adiciona as moedas à carteira;
   - grava o lançamento no ledger.
7. O `purchaseToken` único impede um segundo crédito.
8. Como as moedas são consumíveis, o backend solicita o `consume`.
9. Se o consumo falhar temporariamente, o crédito permanece registrado e deve ser consumido por um retry seguro.
10. RTDN serve para avisar mudanças; o backend consulta a API para confirmar o estado.

Esse desenho segue o fluxo recomendado pelo Google: verificar no servidor antes de conceder o benefício, tratar `PENDING` sem conceder vantagem, e consumir produtos consumíveis depois de conceder o benefício. citeturn0search3turn0search8
