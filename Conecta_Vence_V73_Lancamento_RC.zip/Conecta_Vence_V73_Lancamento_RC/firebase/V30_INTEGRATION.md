# V30 — Sincronização do saldo

Quando o usuário estiver autenticado, `CloudWalletSync.start()` acompanha
o documento `users/{uid}` em tempo real.

A interface pode atualizar automaticamente:
- 🫘 Feijões
- 💎 Diamantes
- 🎁 Presentes enviados
- 💰 Ganhos

Ao sair da conta, chame `stop()`.

Para produção, saldos financeiros não devem ser alterados diretamente pela
interface. Compras e operações financeiras devem continuar passando pelo
backend autorizado.
