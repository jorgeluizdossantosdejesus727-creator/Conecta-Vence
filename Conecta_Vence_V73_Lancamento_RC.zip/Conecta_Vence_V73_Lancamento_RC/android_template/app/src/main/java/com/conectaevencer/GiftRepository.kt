package com.conectaevencer

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class GiftRepository {
    private val auth=FirebaseAuth.getInstance()
    private val db=FirebaseFirestore.getInstance()

    fun sendGift(creatorId:String,gift:Gift,onResult:(Boolean,String?)->Unit) {
        val senderId=auth.currentUser?.uid
        if(senderId==null){onResult(false,"Usuário não autenticado.");return}
        if(creatorId.isBlank()){onResult(false,"Criador inválido.");return}
        db.collection("giftEvents").add(mapOf(
            "senderId" to senderId,"creatorId" to creatorId,
            "giftId" to gift.id,"coinCost" to gift.coinCost,
            "createdAt" to System.currentTimeMillis(),"status" to "pending"
        )).addOnSuccessListener{onResult(true,null)}
         .addOnFailureListener{onResult(false,it.message)}
    }
}
