# V56 — Painel administrativo

A V56 adiciona uma camada administrativa protegida por `x-admin-api-key`.

## Operações

- visualizar saques;
- filtrar por status;
- aprovar saque;
- rejeitar saque;
- registrar referência do pagamento;
- devolver automaticamente o saldo quando um saque pendente é rejeitado;
- visualizar indicadores gerais.

## Segurança

A chave administrativa deve existir somente no servidor através de `ADMIN_API_KEY`.

Para produção, substituir a chave simples por autenticação administrativa forte, controle de funções/permissões, auditoria e proteção contra abuso.

O pagamento ainda não é executado automaticamente: a aprovação apenas muda o estado e registra a referência. A integração com PIX/provedor financeiro deve ser a próxima camada.
