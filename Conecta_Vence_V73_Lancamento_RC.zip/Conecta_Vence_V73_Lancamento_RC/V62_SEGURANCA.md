# V62 — Bloqueio de saque por KYC

Regra de negócio:

**recipient.status = active + kyc_details.status = approved**

Somente essa combinação permite solicitar movimentação.

Estados pendentes, reprovados, cadastro inexistente ou erro de consulta ao
provedor permanecem bloqueados.

## Próxima integração obrigatória

A rota existente que cria o saque deve executar a validação no backend
imediatamente antes de gravar o saque. Também deve autenticar o criador para
impedir que um usuário consulte ou solicite saque em nome de outro.

Esta V62 é a camada de segurança; não contém credenciais reais do Pagar.me.
