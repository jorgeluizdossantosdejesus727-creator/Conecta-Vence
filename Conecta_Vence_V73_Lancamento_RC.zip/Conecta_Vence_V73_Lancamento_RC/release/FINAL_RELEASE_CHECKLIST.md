# V37 — Checklist final antes da publicação

## Projeto
- [ ] applicationId definitivo
- [ ] versionCode/versionName
- [ ] Nome e ícone
- [ ] Política de privacidade e informações da loja

## Serviços reais
- [ ] Firebase real conectado
- [ ] Authentication funcionando
- [ ] Firestore Rules revisadas
- [ ] Backend online
- [ ] Google Play Billing configurado

## Segurança
- [ ] Nenhuma credencial privada no APK
- [ ] Keystore de produção protegida
- [ ] Saldo financeiro controlado pelo servidor
- [ ] purchaseToken validado no backend
- [ ] Proteção contra compra duplicada
- [ ] Saques validados no servidor

## Teste fechado
- [ ] AAB enviado ao Google Play
- [ ] Testadores configurados
- [ ] Cadastro/login
- [ ] Publicações
- [ ] Conversas
- [ ] Fazendinha
- [ ] Feijões/diamantes
- [ ] Presentes
- [ ] Ganhos/saques
- [ ] Compra de teste

## Publicação
- [ ] Nenhum bug crítico
- [ ] Ficha da loja preenchida
- [ ] Classificação indicativa
- [ ] Declarações de conteúdo
- [ ] Enviar para revisão

IMPORTANTE: esta versão é preparação. O AAB real depende do projeto Android,
applicationId, assinatura, Firebase e serviços reais.
