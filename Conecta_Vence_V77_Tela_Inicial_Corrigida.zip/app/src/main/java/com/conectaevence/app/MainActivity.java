package com.conectaevence.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        final FrameLayout root = new FrameLayout(this);
        final WebView web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                root.postDelayed(new Runnable() {
                    @Override public void run() {
                        View splash = root.findViewWithTag("splash");
                        if (splash != null) root.removeView(splash);
                    }
                }, 450);
            }
        });
        web.loadUrl("file:///android_asset/www/index.html");
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        ImageView splash = new ImageView(this);
        splash.setTag("splash");
        splash.setImageResource(com.conectaevence.app.R.drawable.splash_screen);
        splash.setScaleType(ImageView.ScaleType.CENTER_CROP);
        splash.setBackgroundColor(0xFF080A14);
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);
    }
}
