# Conecta & Vence V75 — Tela inicial corrigida

- A tela inicial visual agora está incorporada ao APK como asset local.
- A imagem `conecta_vence_tela_inicial.png` é carregada diretamente pelo WebView.
- A tela de login ganhou sobreposição, marca, descrição, indicadores de segurança e formulário integrado.
- Botões Entrar e Criar conta continuam usando a lógica existente.
- versionCode atualizado para 75 e versionName 1.0.5.
