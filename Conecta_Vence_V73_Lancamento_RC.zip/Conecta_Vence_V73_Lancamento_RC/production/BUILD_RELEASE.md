# Build de produção

Com um projeto Android Gradle real e configurado:

```bash
./gradlew clean
./gradlew bundleRelease
```

O AAB normalmente será produzido em:

`app/build/outputs/bundle/release/`

Depois:
1. validar assinatura;
2. instalar/testar a versão;
3. enviar o AAB para a faixa de teste fechado;
4. executar os testes;
5. somente então considerar produção.

Esta pasta é um guia de configuração; ela não contém um AAB real.
