# V49 — Google Play Billing

O V49 adiciona a camada Android do Google Play Billing para produtos digitais.

Fluxo:
1. O app conecta ao Google Play Billing.
2. Consulta os Product IDs configurados no Play Console.
3. O usuário inicia a compra pelo Google Play.
4. O app recebe o Purchase e o purchaseToken.
5. O token deve ser enviado ao backend seguro.
6. O backend valida o token usando as APIs do Google Play.
7. O backend verifica se o token já foi processado.
8. Só depois da validação o backend credita as moedas.
9. O app consulta o saldo atualizado.

Importante:
- Não coloque credenciais privadas do Google Play dentro do APK.
- Não credite moedas apenas porque o cliente recebeu um callback de compra.
- O purchaseToken deve ser usado para validação e proteção contra replay/duplicação.
