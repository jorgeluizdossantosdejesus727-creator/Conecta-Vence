package com.conectaevencer.billing

/**
 * Contrato para validação de compras no backend.
 * O aplicativo envia o purchaseToken; o servidor valida no Google Play
 * antes de creditar moedas.
 */
data class PurchaseValidationRequest(
    val userId: String,
    val productId: String,
    val purchaseToken: String
)

data class PurchaseValidationResult(
    val approved: Boolean,
    val coins: Int,
    val transactionId: String?
)
