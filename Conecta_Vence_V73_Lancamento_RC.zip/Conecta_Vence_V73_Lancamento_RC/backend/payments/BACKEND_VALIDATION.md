# Validação no servidor

O backend deve receber o purchase token do Google Play e validar a compra antes de creditar moedas.

Campos mínimos recomendados:
- userId
- purchaseToken
- productId
- orderId
- status
- createdAt
- processedAt

Proteções:
- purchaseToken idempotente;
- nunca aceitar saldo enviado pelo cliente;
- registrar auditoria;
- tratar cancelamento/reembolso;
- autenticar o usuário;
- manter segredos apenas no servidor.
