# Checklist de lançamento V71

1. Configurar URL HTTPS do backend de produção.
2. Criar keystore de assinatura privada e guardar fora do projeto.
3. Definir `CV_KEYSTORE_FILE`, `CV_KEYSTORE_PASSWORD`, `CV_KEY_ALIAS` e `CV_KEY_PASSWORD`.
4. Executar `./gradlew clean bundleRelease` para gerar AAB.
5. Executar `./gradlew assembleRelease` para gerar APK.
6. Testar cadastro/login, lives, chat, presentes, carteira e saque em ambiente de produção.
7. Configurar Google Play Billing e verificação de compras no backend.
8. Configurar KYC/pagamentos do provedor financeiro.
9. Revisar política de privacidade, termos, denúncia e segurança.
10. Fazer teste final antes do envio à Google Play.
