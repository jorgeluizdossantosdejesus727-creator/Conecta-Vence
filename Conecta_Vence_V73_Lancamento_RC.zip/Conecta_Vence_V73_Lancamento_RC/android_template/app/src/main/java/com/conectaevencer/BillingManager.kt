package com.conectaevencer

import android.app.Activity
import com.android.billingclient.api.*

class BillingManager(
    private val activity: Activity,
    private val onMessage: (String) -> Unit
) : PurchasesUpdatedListener {

    private val billingClient = BillingClient.newBuilder(activity)
        .setListener(this)
        .enablePendingPurchases()
        .build()

    fun start(productIds: List<String>) {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryProducts(productIds)
                } else {
                    onMessage("Google Play Billing indisponível: ${result.debugMessage}")
                }
            }

            override fun onBillingServiceDisconnected() {
                onMessage("Conexão com Google Play será refeita.")
            }
        })
    }

    private fun queryProducts(productIds: List<String>) {
        val products = productIds.map {
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(it)
                .setProductType(BillingClient.ProductType.INAPP)
                .build()
        }

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(products)
            .build()

        billingClient.queryProductDetailsAsync(params) { result, details ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                onMessage("Não foi possível carregar os produtos.")
                return@queryProductDetailsAsync
            }
            onMessage("${details.productDetailsList.size} pacote(s) disponível(is).")
        }
    }

    fun buy(product: ProductDetails) {
        val offer = product.oneTimePurchaseOfferDetails
            ?: return onMessage("Oferta de compra indisponível.")

        val productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(product)
            .build()

        val flowParams = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(productParams))
            .build()

        billingClient.launchBillingFlow(activity, flowParams)
    }

    override fun onPurchasesUpdated(
        result: BillingResult,
        purchases: MutableList<Purchase>?
    ) {
        if (result.responseCode != BillingClient.BillingResponseCode.OK) {
            onMessage("Compra não concluída: ${result.debugMessage}")
            return
        }

        purchases.orEmpty().forEach { purchase ->
            if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                onMessage("Compra recebida. Validando no servidor...")
                // O purchaseToken deve ser enviado ao backend.
                // O crédito das moedas NÃO deve ser feito apenas no cliente.
            }
        }
    }
}
