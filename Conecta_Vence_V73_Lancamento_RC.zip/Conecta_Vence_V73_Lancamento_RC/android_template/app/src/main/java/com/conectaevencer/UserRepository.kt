package com.conectaevencer

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class UserRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    fun uid(): String? = auth.currentUser?.uid

    fun loadWallet(onResult: (Long, Long, Long) -> Unit) {
        val userId = uid() ?: run {
            onResult(0, 0, 0)
            return
        }
        db.collection("users").document(userId).get()
            .addOnSuccessListener { d ->
                onResult(
                    (d.getLong("beans") ?: 0L),
                    (d.getLong("diamonds") ?: 0L),
                    (d.getLong("coins") ?: 0L)
                )
            }
            .addOnFailureListener { onResult(0, 0, 0) }
    }

    fun harvestBeans(amount: Long, onResult: (Boolean, String?) -> Unit) {
        val userId = uid() ?: run {
            onResult(false, "Usuário não autenticado")
            return
        }
        val ref = db.collection("users").document(userId)
        db.runTransaction { tx ->
            val current = tx.get(ref).getLong("beans") ?: 0L
            tx.update(ref, "beans", current + amount)
        }.addOnSuccessListener {
            onResult(true, null)
        }.addOnFailureListener {
            onResult(false, it.message)
        }
    }
}
