# Conecta & Vence — Backend real (Firebase)

Esta pasta prepara a migração do login local para:
- Firebase Authentication (e-mail/senha)
- Cloud Firestore (perfis e dados do usuário)
- Regras de segurança por usuário

## Para ativar o backend real
1. Crie um projeto no Firebase Console.
2. Ative Authentication > Sign-in method > Email/Password.
3. Crie um Firestore Database.
4. Adicione o app Android ao projeto Firebase e baixe `google-services.json`.
5. Coloque `google-services.json` na pasta do módulo Android (normalmente `app/`).
6. Adicione o plugin Google Services e os SDKs Firebase ao Gradle do projeto.
7. Substitua a camada local de login pela camada Firebase.

## Importante
Não coloque chaves privadas, senhas de administrador ou credenciais de serviço dentro do aplicativo.
O arquivo `google-services.json` é específico do seu projeto Firebase e não pode ser inventado aqui.
