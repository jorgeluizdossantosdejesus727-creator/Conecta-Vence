const API = localStorage.getItem("cv_api_base") || "http://localhost:8080";
const creatorId = new URLSearchParams(location.search).get("creatorId") || "TEST_CREATOR";

const $ = id => document.getElementById(id);

async function load() {
  $("error").textContent = "";
  try {
    const r = await fetch(`${API}/v1/creator/${encodeURIComponent(creatorId)}/kyc-status`);
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || "Falha");

    const s = d.status;
    $("statusCard").className = `status ${s.code}`;

    const icons = {
      not_started: "📝",
      pending: "⏳",
      action_required: "📋",
      approved: "✅",
      rejected: "❌"
    };
    $("statusIcon").textContent = icons[s.code] || "⏳";
    $("statusTitle").textContent = s.label;

    const descriptions = {
      not_started: "Complete o cadastro de recebimento para iniciar.",
      pending: "Seu cadastro está em análise. Aguarde a atualização.",
      action_required: "É necessário concluir a verificação solicitada.",
      approved: "Seu recebimento foi aprovado. Os saques podem ser liberados conforme as regras do aplicativo.",
      rejected: "O cadastro não foi aprovado. Consulte o suporte para saber os próximos passos."
    };
    $("statusText").textContent = descriptions[s.code] || "";

    // The KYC link is generated only by the authenticated creator flow.
    // This demo keeps the button hidden until the app receives a provider URL.
    $("kycButton").hidden = s.code !== "action_required";
  } catch (e) {
    $("error").textContent = e.message;
  }
}

$("refresh").onclick = load;
load();
