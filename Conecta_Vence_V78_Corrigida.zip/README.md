# Conecta & Vence V78

Versão de correção da tela inicial do aplicativo.

## O que mudou
- Removido o carregamento da tela inicial por WebView.
- A tela inicial agora é nativa para reduzir falhas de abertura.
- Visual inicial usa a arte aprovada do projeto.
- Entrar e Criar conta abrem telas nativas.
- Tela Início foi redesenhada no estilo escuro/pink do protótipo.
- Funciona offline para o fluxo de demonstração.

Esta versão é para teste; pagamentos, lives reais e backend de produção ainda precisam de integração e validação antes de lançamento público.
