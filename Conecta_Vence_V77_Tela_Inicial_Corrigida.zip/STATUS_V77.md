# Conecta & Vence V77 — Tela Inicial Corrigida

- Tela de abertura nativa exibindo a arte da tela inicial antes do WebView.
- Tela inicial do WebView usa a arte visual da primeira tela do protótipo.
- Ícone personalizado do aplicativo.
- Botões invisíveis sobre as áreas de Entrar e Criar conta para manter a navegação.
- VersionCode 77 / versionName 1.0.6.
