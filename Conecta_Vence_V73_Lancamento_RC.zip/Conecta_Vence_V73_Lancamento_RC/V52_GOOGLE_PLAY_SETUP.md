# V52 — Configuração real

## Variáveis do servidor

- `PACKAGE_NAME` = applicationId real publicado no Google Play.
- `GOOGLE_SERVICE_ACCOUNT_JSON` = credenciais da conta de serviço com acesso adequado à Google Play Developer API.
- `DB_PATH` = caminho do banco persistente.

## RTDN

O Google Play envia RTDN usando Cloud Pub/Sub. A notificação informa que o estado mudou; ela não substitui a consulta à Google Play Developer API. Depois de receber a notificação, o backend deve consultar a API e atualizar seu próprio estado. citeturn0search0turn0search9

## Compra de produto único

Para produtos in-app, a Google Play Developer API possui `purchases.products.get`, além de operações de acknowledge/consume. citeturn0search7turn0search13

## Segurança

As credenciais ficam somente no servidor. O APK nunca recebe a chave privada.

Antes de liberar o aplicativo real, configure:
1. Google Play Console.
2. Google Cloud/conta de serviço.
3. API Android Publisher.
4. Tópico Cloud Pub/Sub.
5. HTTPS.
6. Banco persistente gerenciado.
7. Testadores licenciados.
8. Testes de compra, cancelamento e reembolso.
