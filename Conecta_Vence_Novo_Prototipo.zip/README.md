# Conecta & Vence — novo protótipo

Novo protótipo independente, inspirado no modelo visual enviado:
- tema escuro com roxo/rosa
- login e criação de conta
- Início
- Perfil
- Lives
- Conversas
- Carteira
- Compra de moedas
- Metas e recompensas
- interação de presentes e saque em modo demonstrativo
- navegação inferior responsiva
- PWA/manifesto para instalação como aplicativo web

## Teste
Abra `index.html` em um navegador moderno. Para instalação como PWA, publique os arquivos em um servidor HTTPS.
