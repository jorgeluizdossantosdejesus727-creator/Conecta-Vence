# V25 — Banco + crédito idempotente

A V25 conecta a validação da compra ao Cloud Firestore.

Fluxo:
1. Google Play confirma a compra.
2. O servidor valida o purchaseToken.
3. O servidor abre uma transação Firestore.
4. O documento purchaseTransactions/<transactionId> é consultado.
5. Se já existir, nenhuma moeda é creditada novamente.
6. Se não existir, o saldo é incrementado e a transação é registrada atomicamente.

O Firestore suporta transações atômicas e pode repetir a função de transação em caso de concorrência; por isso a função não deve produzir efeitos externos durante a transação. citeturn0search0

Antes de produção:
- configurar Firebase Admin no ambiente do servidor;
- configurar PACKAGE_NAME;
- configurar autenticação do usuário;
- criar índices/regras conforme o projeto;
- testar compras, reembolsos e concorrência;
- nunca colocar credenciais de servidor no APK.
