package com.conectaevencer

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class SocialRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private fun uid(): String? = auth.currentUser?.uid

    fun createPost(text: String, onResult: (Boolean, String?) -> Unit) {
        val userId = uid()
        if (userId == null) {
            onResult(false, "Usuário não autenticado")
            return
        }

        db.collection("posts").add(
            mapOf(
                "authorId" to userId,
                "text" to text,
                "createdAt" to System.currentTimeMillis()
            )
        ).addOnSuccessListener {
            onResult(true, null)
        }.addOnFailureListener {
            onResult(false, it.message)
        }
    }

    fun sendMessage(
        recipientId: String,
        text: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val senderId = uid()
        if (senderId == null) {
            onResult(false, "Usuário não autenticado")
            return
        }

        db.collection("conversations")
            .document("${senderId}_$recipientId")
            .collection("messages")
            .add(
                mapOf(
                    "senderId" to senderId,
                    "recipientId" to recipientId,
                    "text" to text,
                    "createdAt" to System.currentTimeMillis()
                )
            )
            .addOnSuccessListener {
                onResult(true, null)
            }
            .addOnFailureListener {
                onResult(false, it.message)
            }
    }
}
