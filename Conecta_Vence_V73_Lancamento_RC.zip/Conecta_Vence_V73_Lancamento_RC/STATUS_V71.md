# Conecta & Vence — V71

Android final release preparation based on V63.

Included:
- Android Gradle project
- applicationId com.conectavence.app
- release build configuration
- versionCode 71 / versionName 1.0.0
- release signing template using environment variables
- production-release checklist
- APK/AAB build commands

Important: no real signing key or Play Console credentials are included. Before publishing, configure a private keystore and production backend/payment credentials.
