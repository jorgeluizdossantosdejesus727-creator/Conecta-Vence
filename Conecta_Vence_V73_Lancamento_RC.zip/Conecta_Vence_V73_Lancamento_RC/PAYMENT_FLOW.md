# V47 — Fluxo seguro de compras

1. O usuário escolhe um pacote de moedas no Google Play.
2. O Google Play retorna a compra e o `purchaseToken`.
3. O aplicativo envia o token para validação.
4. O backend consulta/valida a compra com o Google Play.
5. O backend verifica se o `purchaseToken` já foi processado.
6. Somente uma compra válida e ainda não processada pode gerar crédito.
7. O backend grava a transação como processada de forma idempotente.
8. O aplicativo consulta o saldo atualizado.

IMPORTANTE:
- Nunca conceder moedas apenas porque o cliente informou um preço ou quantidade.
- Nunca guardar a chave privada do Google Play no aplicativo.
- A validação definitiva deve acontecer no backend.
- O mesmo `purchaseToken` não pode gerar crédito duas vezes.
