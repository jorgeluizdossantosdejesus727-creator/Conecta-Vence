# Adicione somente regras necessárias após os testes.
# Não desative a proteção inteira sem motivo.
