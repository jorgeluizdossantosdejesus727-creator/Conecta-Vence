# V60 — Cadastro e KYC dos criadores

## Fluxo

1. Criador inicia o cadastro de recebimento.
2. Backend cria um `recipient` no Pagar.me.
3. O `recipient_id` fica vinculado ao criador.
4. O backend acompanha `recipient.status` e `kyc_details`.
5. Quando o provedor disponibilizar o estágio de KYC, o backend cria o link de prova de vida.
6. O criador conclui o processo no fluxo do provedor.
7. Um webhook `recipient.updated` atualiza o status interno.
8. Somente um recebedor apto deve seguir para pagamento.

A documentação atual do Pagar.me descreve o fluxo de prova de vida/KYC com `kyc_details`, `recipient.updated` e a rota `POST /recipients/{id}/kyc_link`. Ela também informa que o link de KYC expira em 20 minutos. citeturn0search0

## Regra importante

O aplicativo não deve tentar fazer o KYC por conta própria nem guardar documentos sensíveis desnecessariamente. O cadastro deve ser autenticado e os dados enviados ao provedor conforme o contrato vigente.

O Pagar.me informa que o contrato atual de recebedores exige dados cadastrais mínimos para sellers e possui fluxos específicos para PF/PJ. citeturn0search3turn0search4

## Antes de produção

- autenticar o criador;
- validar CPF/CNPJ e dados exigidos;
- usar HTTPS;
- validar webhooks;
- proteger dados pessoais;
- testar o fluxo completo;
- confirmar os campos obrigatórios da conta Pagar.me de produção.
