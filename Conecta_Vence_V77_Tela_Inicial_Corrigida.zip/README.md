# Conecta & Vence — Android 1.0

Esta é a primeira base de aplicativo Android real, usando a V17 como interface local.

## Abrir
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Execute em um aparelho Android ou emulador.
4. Para publicar, gere um **Android App Bundle (AAB)** assinado.

## Importante
Esta versão ainda não é um serviço de produção: login, banco de dados na nuvem, pagamentos, lives, saques e moderação ainda precisam de backend seguro e integrações reais antes da publicação comercial.
