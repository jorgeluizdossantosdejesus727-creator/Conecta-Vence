# V59 — PIX e pagamento dos saques

A V59 prepara o pagamento real dos saques usando uma conta de marketplace/recebedores do Pagar.me.

## Fluxo

1. Criador conclui cadastro e KYC.
2. O provedor cria/identifica o `recipient`.
3. O app registra o `recipient_id`.
4. Administrador aprova o saque.
5. O backend envia uma transferência ao Pagar.me.
6. O saque interno passa para `processing`.
7. O webhook do provedor confirma sucesso ou falha.
8. O histórico interno é atualizado.

O Pagar.me documenta recebedores (`recipients`) para marketplaces e saques manuais via API; a documentação também informa que o recebedor precisa estar apto a movimentar o saldo e que a API V5 é a versão atual recomendada. citeturn1search0turn1search2turn1search4

## Importante

A V59 NÃO coloca uma chave real de pagamento no projeto. Configure `PAGARME_SECRET_KEY` somente como segredo do servidor.

Antes de pagar dinheiro real:
- concluir KYC;
- validar o contrato/conta Pagar.me;
- confirmar os endpoints e eventos da V5 habilitados na conta;
- validar assinatura do webhook;
- testar em sandbox;
- fazer conciliação;
- configurar limites e antifraude.

O Pagar.me também oferece Pix e split para operações de marketplace. citeturn1search6turn0search17
