# V20 — Carteira e pagamentos (preparação segura)

A V20 prepara a arquitetura para pagamentos reais sem colocar segredo dentro do aplicativo.

Fluxo recomendado:
1. Usuário compra um pacote de moedas.
2. O aplicativo solicita ao servidor uma cobrança.
3. O servidor cria a cobrança no provedor de pagamentos.
4. O provedor confirma o pagamento por webhook.
5. O servidor credita as moedas somente após confirmação.
6. O servidor registra a transação com ID único para impedir crédito duplicado.
7. Presentes consomem moedas/diamantes através de transações no servidor.
8. Ganhos do criador ficam separados do saldo do usuário.
9. Saques somente após validações e regras de elegibilidade.

IMPORTANTE:
- Nenhuma chave secreta é incluída neste projeto.
- Não é seguro liberar moedas apenas porque o aplicativo recebeu uma resposta local.
- Para ativar pagamentos reais, é necessário escolher e conectar uma conta de provedor de pagamentos.
