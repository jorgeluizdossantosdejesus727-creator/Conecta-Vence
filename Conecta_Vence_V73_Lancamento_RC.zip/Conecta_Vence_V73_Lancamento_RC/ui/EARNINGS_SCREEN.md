# V32 — Tela de Ganhos e Saque

Elementos da tela:
- Ganhos disponíveis
- Ganhos pendentes
- Total sacado
- Valor mínimo para saque
- Campo para informar o valor
- Botão **Solicitar saque**
- Lista de solicitações recentes
- Status: pendente, pago ou falhou

Fluxo:
Ganhos → Solicitar saque → confirmação → backend → status da solicitação.

A tela nunca deve alterar o saldo diretamente. Ela apenas envia a solicitação
ao backend, que valida saldo, elegibilidade e dados de pagamento.
