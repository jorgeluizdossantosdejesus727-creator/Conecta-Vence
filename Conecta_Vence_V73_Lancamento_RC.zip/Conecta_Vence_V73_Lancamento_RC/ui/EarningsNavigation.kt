package com.conectaevencer.ui

/**
 * V33 — Integração da área de Ganhos/Saque à navegação.
 */
enum class AppDestination {
    HOME,
    POSTS,
    CONVERSATIONS,
    FARM,
    PROFILE,
    EARNINGS
}

class EarningsNavigation {
    var current: AppDestination = AppDestination.HOME
        private set

    fun openEarnings() {
        current = AppDestination.EARNINGS
    }

    fun back() {
        current = AppDestination.PROFILE
    }
}
