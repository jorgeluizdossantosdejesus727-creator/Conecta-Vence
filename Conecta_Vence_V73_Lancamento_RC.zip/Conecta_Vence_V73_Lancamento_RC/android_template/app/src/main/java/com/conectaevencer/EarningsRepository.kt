package com.conectaevencer

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

data class Earnings(
    val availableCents: Long = 0,
    val pendingCents: Long = 0,
    val withdrawnCents: Long = 0
)

class EarningsRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private fun uid(): String? = auth.currentUser?.uid

    fun loadEarnings(onResult: (Earnings) -> Unit) {
        val userId = uid() ?: run {
            onResult(Earnings())
            return
        }

        db.collection("users").document(userId).collection("earnings")
            .document("summary").get()
            .addOnSuccessListener { d ->
                onResult(
                    Earnings(
                        availableCents = d.getLong("availableCents") ?: 0,
                        pendingCents = d.getLong("pendingCents") ?: 0,
                        withdrawnCents = d.getLong("withdrawnCents") ?: 0
                    )
                )
            }
            .addOnFailureListener { onResult(Earnings()) }
    }

    fun requestWithdrawal(
        amountCents: Long,
        onResult: (Boolean, String?) -> Unit
    ) {
        val userId = uid()
        if (userId == null) {
            onResult(false, "Usuário não autenticado.")
            return
        }
        if (amountCents <= 0) {
            onResult(false, "Valor inválido.")
            return
        }

        val request = hashMapOf(
            "userId" to userId,
            "amountCents" to amountCents,
            "status" to "pending",
            "createdAt" to System.currentTimeMillis()
        )

        db.collection("withdrawalRequests")
            .add(request)
            .addOnSuccessListener {
                onResult(true, null)
            }
            .addOnFailureListener {
                onResult(false, it.message)
            }
    }
}
