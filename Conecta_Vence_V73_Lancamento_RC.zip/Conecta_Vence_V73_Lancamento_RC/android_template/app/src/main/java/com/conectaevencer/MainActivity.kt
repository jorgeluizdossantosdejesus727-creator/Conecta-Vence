package com.conectaevencer

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity:Activity(){
    private lateinit var content:LinearLayout
    private val gifts=GiftRepository()

    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);showHome()}
    private fun base()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,48,24,24)}
    private fun title(t:String)=TextView(this).apply{text=t;textSize=26f;gravity=Gravity.CENTER;setTextColor(Color.BLACK);setPadding(0,0,0,20)}
    private fun button(t:String,a:()->Unit)=Button(this).apply{text=t;setOnClickListener{a()}}

    private fun showHome(){
        content=base();content.addView(title("Conecta & Vence"))
        content.addView(button("🪙 Moedas"){showCoins()})
        content.addView(button("🎁 Presentes"){showGifts()})
        content.addView(button("🏆 Recompensas"){showRewards()})
        setContentView(content)
    }

    private fun showCoins(){
        content=base();content.addView(title("🪙 Pacotes de Moedas"))
        RewardsCatalog.coinPackages.forEach{p->content.addView(TextView(this).apply{
            text="${p.coins} moedas — R$ %.2f".format(p.priceCents/100.0);textSize=18f;setPadding(0,10,0,10)
        })}
        content.addView(TextView(this).apply{text="A compra real será concluída pelo Google Play Billing.";setPadding(0,16,0,16)})
        content.addView(button("Voltar"){showHome()});setContentView(content)
    }

    private fun showGifts(){
        content=base();content.addView(title("🎁 Presentes"))
        val creator=EditText(this).apply{hint="ID do criador"};val status=TextView(this)
        content.addView(creator)
        RewardsCatalog.gifts.forEach{g->content.addView(button("${g.name} — ${g.coinCost} moedas"){
            gifts.sendGift(creator.text.toString().trim(),g){ok,error->runOnUiThread{
                status.text=if(ok)"Presente registrado para validação." else "Erro: ${error?:"falha"}"
            }}
        })}
        content.addView(status);content.addView(button("Voltar"){showHome()});setContentView(content)
    }

    private fun showRewards(){
        content=base();content.addView(title("🏆 Recompensas"))
        RewardsCatalog.goals.forEach{g->content.addView(TextView(this).apply{
            text="${g.title}\nMeta: ${g.target} • Bônus: ${g.bonusCoins} moedas";textSize=18f;setPadding(0,12,0,12)
        })}
        content.addView(button("Voltar"){showHome()});setContentView(content)
    }
}
