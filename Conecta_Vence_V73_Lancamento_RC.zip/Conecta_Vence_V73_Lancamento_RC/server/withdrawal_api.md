# V31 — Ganhos e saques

Endpoints sugeridos:

GET /api/creator/earnings
POST /api/creator/withdrawals

Fluxo seguro:
1. Usuário autenticado consulta ganhos.
2. Backend calcula o saldo disponível.
3. Usuário solicita um saque dentro das regras.
4. Backend cria uma solicitação `pending`.
5. Valida identidade, elegibilidade, saldo e dados de pagamento.
6. Processa o pagamento por um provedor apropriado.
7. Atualiza o status para `paid` ou `failed`.
8. Registra toda a operação no histórico.

Nunca permitir que o aplicativo envie um novo saldo e o servidor simplesmente aceite.
O valor do saque deve ser calculado no servidor.

Antes de dinheiro real:
- definir regras de elegibilidade;
- definir valor mínimo;
- implementar antifraude;
- configurar provedor de pagamentos/payout;
- validar identidade e dados exigidos;
- tratar estornos e falhas.
