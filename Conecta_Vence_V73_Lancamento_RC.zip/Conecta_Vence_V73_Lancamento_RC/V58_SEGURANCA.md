# V58 — Autenticação e segurança administrativa

A V58 troca a chave administrativa fixa por login + sessão assinada.

## Variáveis necessárias

- `ADMIN_USER`
- `ADMIN_PASSWORD_HASH`
- `ADMIN_SESSION_SECRET`

O `ADMIN_SESSION_SECRET` deve ser um segredo aleatório forte e permanecer somente no servidor.

## Produção

Esta implementação é uma base de protótipo. Antes de publicar:
- colocar o painel e API atrás de HTTPS;
- usar armazenamento persistente/distribuído de sessões;
- aplicar rate limiting e proteção contra brute force;
- ativar MFA/2FA;
- usar RBAC;
- registrar auditoria de aprovações/rejeições;
- proteger CORS;
- armazenar segredos em um secret manager.

Não coloque a senha, o hash ou o segredo do servidor dentro do APK ou do código público do painel.
