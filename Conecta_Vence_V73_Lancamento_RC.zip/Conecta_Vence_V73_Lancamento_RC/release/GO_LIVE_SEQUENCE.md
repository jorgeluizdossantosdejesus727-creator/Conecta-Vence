# V37 — Sequência final

1. Abrir o projeto Android real.
2. Configurar applicationId e versão.
3. Conectar Firebase real.
4. Configurar backend.
5. Configurar produtos do Google Play Billing.
6. Configurar assinatura de release.
7. Executar `./gradlew bundleRelease`.
8. Enviar o AAB para teste fechado.
9. Executar os testes.
10. Corrigir falhas.
11. Promover para produção após aprovação.

Não coloque credenciais privadas ou a chave de assinatura no ZIP.
