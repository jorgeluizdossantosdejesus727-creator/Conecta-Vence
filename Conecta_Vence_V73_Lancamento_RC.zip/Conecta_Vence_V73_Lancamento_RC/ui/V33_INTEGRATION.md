# V33 — Integração da área de Ganhos

A área de Ganhos/Saque passa a fazer parte da navegação principal do aplicativo.

Entrada recomendada:
**Meu Perfil → Ganhos e Saque**

A tela deve exibir:
- saldo disponível;
- saldo pendente;
- total sacado;
- botão Solicitar saque;
- histórico de solicitações.

A navegação é apenas uma camada de interface. O backend continua sendo a
autoridade para saldo, elegibilidade e processamento financeiro.
