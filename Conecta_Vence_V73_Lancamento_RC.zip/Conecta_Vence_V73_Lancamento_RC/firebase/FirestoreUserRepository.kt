package com.conectaevencer.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions

data class UserProfile(
    val name: String = "",
    val email: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

class FirestoreUserRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private fun uid(): String =
        auth.currentUser?.uid ?: throw IllegalStateException("Usuário não autenticado")

    fun saveProfile(profile: UserProfile, onResult: (Boolean, String?) -> Unit) {
        db.collection("users").document(uid())
            .set(profile, SetOptions.merge())
            .addOnSuccessListener { onResult(true, null) }
            .addOnFailureListener { onResult(false, it.message) }
    }

    fun loadProfile(onResult: (UserProfile?, String?) -> Unit) {
        db.collection("users").document(uid()).get()
            .addOnSuccessListener { snap ->
                onResult(snap.toObject(UserProfile::class.java), null)
            }
            .addOnFailureListener { onResult(null, it.message) }
    }

    fun addHistory(type: String, detail: String, onResult: (Boolean, String?) -> Unit) {
        val data = hashMapOf(
            "type" to type,
            "detail" to detail,
            "createdAt" to System.currentTimeMillis()
        )
        db.collection("users").document(uid())
            .collection("history")
            .add(data)
            .addOnSuccessListener { onResult(true, null) }
            .addOnFailureListener { onResult(false, it.message) }
    }

    fun listenHistory(
        onChange: (List<Map<String, Any>>) -> Unit,
        onError: (Exception) -> Unit
    ): ListenerRegistration {
        return db.collection("users").document(uid())
            .collection("history")
            .orderBy("createdAt")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onError(error)
                    return@addSnapshotListener
                }
                onChange(snapshot?.documents?.map { it.data ?: emptyMap() } ?: emptyList())
            }
    }
}
