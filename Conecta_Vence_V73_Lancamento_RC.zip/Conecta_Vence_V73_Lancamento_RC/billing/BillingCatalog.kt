package com.conectaevencer.billing

object BillingCatalog {
    const val COINS_1000 = "coins_1000"
    const val COINS_5000 = "coins_5000"
    const val COINS_12000 = "coins_12000"
    val products = listOf(COINS_1000, COINS_5000, COINS_12000)
}
