# V34 — Plano de teste ponta a ponta

## Conta
- [ ] Criar conta
- [ ] Fazer login
- [ ] Fazer logout
- [ ] Entrar novamente com a mesma conta

## Perfil e nuvem
- [ ] Salvar perfil
- [ ] Reabrir o app e confirmar os dados
- [ ] Confirmar que outro usuário não vê os dados

## Fazenda
- [ ] Colher feijões
- [ ] Conferir registro no histórico
- [ ] Confirmar sincronização

## Carteira
- [ ] Conferir feijões
- [ ] Conferir diamantes
- [ ] Conferir presentes
- [ ] Conferir ganhos

## Publicações e conversas
- [ ] Criar publicação
- [ ] Abrir publicação
- [ ] Enviar mensagem
- [ ] Receber mensagem

## Ganhos e saque
- [ ] Abrir Meu Perfil → Ganhos e Saque
- [ ] Conferir saldo
- [ ] Solicitar saque
- [ ] Conferir status pendente
- [ ] Confirmar que o cliente não consegue alterar o saldo

## Pagamentos
- [ ] Fazer compra de teste no Google Play
- [ ] Validar purchaseToken no backend
- [ ] Confirmar crédito uma única vez
- [ ] Repetir o mesmo token e confirmar que não duplica

## Segurança
- [ ] Usuário não autenticado não acessa dados privados
- [ ] Não existem credenciais privadas no APK
- [ ] Erros de rede são tratados
