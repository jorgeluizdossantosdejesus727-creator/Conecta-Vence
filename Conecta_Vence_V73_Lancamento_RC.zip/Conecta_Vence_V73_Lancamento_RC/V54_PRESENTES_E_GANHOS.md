# V54 — Presentes e ganhos do criador

## Fluxo

1. O usuário possui moedas na carteira.
2. Escolhe um presente durante a live/conversa.
3. O servidor valida o evento.
4. O servidor verifica o saldo.
5. Em uma única transação:
   - debita as moedas do usuário;
   - grava o `gift_debit` no ledger;
   - credita o saldo do criador;
   - grava o evento no ledger do criador;
   - marca o evento como concluído.
6. O `eventId` único impede duplicação.

### Regra atual

- Coração: 10 moedas → 7 de valor do criador
- Rosa: 25 moedas → 18
- Estrela: 50 moedas → 35
- Troféu: 100 moedas → 70

Os valores são internos ao sistema e devem ser revisados antes da publicação comercial.

O Google Play classifica moedas digitais como produtos consumíveis, que podem ser comprados novamente depois de consumidos. citeturn0search0turn0search8
