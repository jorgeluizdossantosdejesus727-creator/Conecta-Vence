import express from "express";
import { google } from "googleapis";
import admin from "firebase-admin";

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 8080;
const PACKAGE_NAME = process.env.PACKAGE_NAME;

if (!admin.apps.length) {
  admin.initializeApp();
}
const db = admin.firestore();

const COINS = {
  coins_1000: 1000,
  coins_5000: 5000,
  coins_12000: 12000
};

function getAndroidPublisher() {
  const auth = new google.auth.GoogleAuth({
    scopes: ["https://www.googleapis.com/auth/androidpublisher"]
  });
  return google.androidpublisher({ version: "v3", auth });
}

app.post("/api/purchases/google-play/validate", async (req, res) => {
  try {
    const { userId, productId, purchaseToken } = req.body || {};

    if (!userId || !productId || !purchaseToken) {
      return res.status(400).json({ approved: false, error: "Dados incompletos." });
    }

    if (!PACKAGE_NAME || !COINS[productId]) {
      return res.status(500).json({ approved: false, error: "Configuração inválida." });
    }

    const publisher = getAndroidPublisher();
    const result = await publisher.purchases.products.get({
      packageName: PACKAGE_NAME,
      productId,
      token: purchaseToken
    });

    const purchase = result.data;

    if (purchase.purchaseState !== 0) {
      return res.status(409).json({ approved: false, error: "Compra não confirmada." });
    }

    const transactionId = purchase.orderId || purchaseToken;
    const transactionRef = db.collection("purchaseTransactions").doc(transactionId);
    const userRef = db.collection("users").doc(userId);

    const resultTx = await db.runTransaction(async (tx) => {
      const existing = await tx.get(transactionRef);

      if (existing.exists) {
        return {
          approved: true,
          duplicate: true,
          coins: existing.data().coinsGranted || 0,
          transactionId
        };
      }

      const userSnap = await tx.get(userRef);
      const currentCoins = Number(userSnap.exists ? userSnap.data().coins || 0 : 0);
      const coins = COINS[productId];

      tx.set(userRef, {
        coins: currentCoins + coins,
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      }, { merge: true });

      tx.create(transactionRef, {
        userId,
        productId,
        purchaseToken,
        orderId: purchase.orderId || null,
        coinsGranted: coins,
        status: "granted",
        createdAt: admin.firestore.FieldValue.serverTimestamp()
      });

      return {
        approved: true,
        duplicate: false,
        coins,
        transactionId
      };
    });

    return res.json(resultTx);
  } catch (error) {
    console.error(error?.response?.data || error);
    return res.status(502).json({
      approved: false,
      error: "Falha na validação ou no banco de dados."
    });
  }
});

app.get("/health", (_req, res) => res.json({
  ok: true,
  service: "conecta-vence-backend",
  version: "25"
}));

app.listen(PORT, () => console.log(`Backend V25 na porta ${PORT}`));
