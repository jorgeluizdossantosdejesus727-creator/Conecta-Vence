# V61 — Status do KYC no aplicativo

O aplicativo agora tem uma camada de apresentação para o criador:

- **Cadastro não iniciado**
- **Aguardando aprovação**
- **Ação necessária**
- **Aprovado**
- **Reprovado**

A normalização considera o status do recebedor e `kyc_details`. A documentação do Pagar.me descreve `registration`, `affiliation`, `active` e `refused`, além dos estados de `kyc_details` como `pending`, `partially_denied`, `approved` e `denied`. O recebedor só fica apto a movimentar saldo quando estiver `active`. citeturn0search0

O endpoint do aplicativo também informa `canWithdraw`, permitindo bloquear a tela de saque até o KYC estar aprovado.

Antes da produção, o endpoint deve exigir autenticação do próprio criador. Não é seguro deixar um usuário consultar ou alterar dados de outro criador apenas fornecendo um `creatorId`.
