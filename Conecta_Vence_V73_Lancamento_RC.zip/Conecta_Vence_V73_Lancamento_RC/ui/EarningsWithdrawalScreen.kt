package com.conectaevencer.ui

/**
 * V32 — Modelo de estado para a tela de Ganhos e Saque.
 * A UI deve consumir dados vindos do backend; não calcula saldo financeiro.
 */
data class EarningsUiState(
    val availableCents: Long = 0,
    val pendingCents: Long = 0,
    val withdrawnCents: Long = 0,
    val minimumWithdrawalCents: Long = 0,
    val withdrawalInProgress: Boolean = false,
    val message: String? = null
)

class EarningsWithdrawalController(
    private val api: EarningsWithdrawalApi
) {
    fun load(onResult: (EarningsUiState?, String?) -> Unit) {
        api.getEarnings(onResult)
    }

    fun requestWithdrawal(
        amountCents: Long,
        onResult: (Boolean, String?) -> Unit
    ) {
        if (amountCents <= 0) {
            onResult(false, "Informe um valor válido.")
            return
        }
        api.requestWithdrawal(amountCents, onResult)
    }
}

interface EarningsWithdrawalApi {
    fun getEarnings(onResult: (EarningsUiState?, String?) -> Unit)
    fun requestWithdrawal(amountCents: Long, onResult: (Boolean, String?) -> Unit)
}
