# Conecta & Vence — V73 Release Candidate

## Concluído nesta etapa
- Consolidação do projeto Android de V71.
- Checklist de pré-lançamento.
- Validação de que a assinatura de release ainda precisa das credenciais/keystore do proprietário.
- Validação de que o backend de produção precisa de domínio HTTPS e credenciais reais.

## Antes de publicar
1. Definir applicationId definitivo.
2. Criar keystore de produção e guardar a senha fora do projeto.
3. Configurar Play Console e produto(s) de moedas.
4. Configurar backend HTTPS e credenciais de produção.
5. Configurar Google Play Billing e validação no backend.
6. Configurar KYC/Pagar.me com credenciais de produção.
7. Testar cadastro, login, live, chat, presente, saldo, saque e denúncias.
8. Gerar AAB assinado em máquina com Android SDK/Gradle e keystore.
9. Fazer teste fechado no Google Play antes do lançamento público.

## Importante
Este pacote é um Release Candidate de código/configuração. Não contém uma chave de assinatura real, credenciais de pagamento ou credenciais do Google Play; portanto, não é correto afirmar que um AAB de produção já está assinado.
