# V36 — Preparação do AAB Release

## Identidade
- [ ] Definir applicationId definitivo
- [ ] Definir nome Conecta & Vence
- [ ] Definir versionCode
- [ ] Definir versionName

## Assinatura
- [ ] Criar/manter keystore de produção em local seguro
- [ ] Configurar assinatura do release
- [ ] Nunca enviar keystore ou senha para o repositório

## Firebase
- [ ] Usar google-services.json do projeto real
- [ ] Conferir applicationId
- [ ] Conferir Authentication
- [ ] Conferir Firestore Rules
- [ ] Conferir backend de pagamentos

## Google Play
- [ ] Configurar ficha da loja
- [ ] Configurar produtos digitais
- [ ] Configurar testers
- [ ] Enviar AAB para teste
- [ ] Verificar resultado dos testes

## Validação final
- [ ] Cadastro/login
- [ ] Publicações
- [ ] Conversas
- [ ] Fazendinha
- [ ] Feijões/diamantes
- [ ] Presentes
- [ ] Ganhos
- [ ] Saque
- [ ] Compra de teste
- [ ] Segurança

## Regra
O AAB de produção deve ser gerado somente depois que os itens acima forem
conferidos no ambiente real. Não incluir credenciais privadas no projeto.
