# Conecta & Vence V78

Release candidate de correção visual e inicialização.

- Tela inicial nativa, sem WebView.
- Abertura direta e offline.
- Visual inicial baseado na arte aprovada.
- Botões Entrar e Criar conta funcionais.
- Tela Início com navegação visual e cartões.
- versionCode 78 / versionName 1.0.7.
