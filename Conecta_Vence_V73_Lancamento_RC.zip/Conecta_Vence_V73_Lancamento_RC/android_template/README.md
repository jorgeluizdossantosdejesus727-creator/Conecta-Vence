# V39 — Estrutura base para AAB

Esta pasta fornece os arquivos-modelo para um projeto Android Gradle.

Antes de compilar:
1. Renomeie/remova `.template` conforme a estrutura do projeto.
2. Substitua `applicationId` pelo identificador real.
3. Configure `google-services.json` real.
4. Configure dependências e versão do Gradle/Android Gradle Plugin compatíveis.
5. Configure a assinatura release fora do repositório.
6. Integre as telas e classes das versões anteriores.
7. Execute `./gradlew bundleRelease`.

Este material não é um projeto completo compilável nem contém credenciais ou
uma chave de assinatura. O AAB real precisa ser gerado no projeto Android
final, com os serviços reais configurados.
