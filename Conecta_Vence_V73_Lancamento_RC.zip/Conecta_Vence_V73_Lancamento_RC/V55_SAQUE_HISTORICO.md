# V55 — Saque e histórico financeiro

## Fluxo de saque

1. O criador solicita um saque.
2. O servidor verifica o saldo.
3. O valor é reservado/debitado atomicamente da carteira de ganhos.
4. A solicitação é criada como `pending`.
5. Um ID único impede duplicação.
6. O pagamento real deverá ser executado por um provedor/PIX após as verificações necessárias.
7. Se a solicitação for rejeitada antes do pagamento, o backend de produção deve devolver o valor por uma transação compensatória no ledger.

## Histórico

O endpoint financeiro retorna:
- saldo atual;
- ganhos recebidos;
- presentes que geraram cada ganho;
- saques solicitados;
- status e referência do pagamento.

**Importante:** esta V55 prepara o fluxo financeiro, mas não configura uma transferência PIX real nem KYC. Essas etapas precisam ser integradas a um provedor de pagamentos e às regras aplicáveis antes de disponibilizar saques reais.
