package com.conectaevencer

data class CoinPackage(val productId:String,val coins:Long,val priceCents:Long)
data class Gift(val id:String,val name:String,val coinCost:Long,val creatorValue:Long)
data class RewardGoal(val id:String,val title:String,val target:Long,val bonusCoins:Long)

object RewardsCatalog {
    val coinPackages=listOf(
        CoinPackage("coins_1000",1000,500),
        CoinPackage("coins_2500",2500,1000),
        CoinPackage("coins_6000",6000,2000)
    )
    val gifts=listOf(
        Gift("heart","Coração",10,7),
        Gift("star","Estrela",50,35),
        Gift("trophy","Troféu",100,70),
        Gift("rose","Rosa",25,18)
    )
    val goals=listOf(
        RewardGoal("goal_35_gifts","Receber 35 presentes",35,500),
        RewardGoal("goal_2h_live","Ficar 2 horas ao vivo",120,750),
        RewardGoal("goal_100_viewers","Alcançar 100 espectadores",100,1000)
    )
}
