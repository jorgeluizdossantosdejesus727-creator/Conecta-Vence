package com.conectaevencer.earnings

data class CreatorEarnings(
    val availableCents: Long = 0,
    val pendingCents: Long = 0,
    val withdrawnCents: Long = 0
)

data class WithdrawalRequest(
    val userId: String,
    val amountCents: Long,
    val status: String = "pending",
    val createdAt: Long = System.currentTimeMillis()
)
