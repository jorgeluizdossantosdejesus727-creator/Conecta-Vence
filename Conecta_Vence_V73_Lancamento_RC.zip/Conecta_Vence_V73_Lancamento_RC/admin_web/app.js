const API = localStorage.getItem("cv_api_base") || "http://localhost:8080";
let TOKEN = sessionStorage.getItem("cv_admin_token") || "";

const $ = id => document.getElementById(id);

function headers() {
  return {
    "Content-Type": "application/json",
    ...(TOKEN ? { "Authorization": `Bearer ${TOKEN}` } : {})
  };
}

async function getJSON(path, options = {}) {
  const r = await fetch(API + path, {
    ...options,
    headers: { ...headers(), ...(options.headers || {}) }
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (r.status === 401) logout(false);
    throw new Error(data.error || `HTTP ${r.status}`);
  }
  return data;
}

async function login() {
  const username = $("username").value.trim();
  const password = $("password").value;

  try {
    const data = await getJSON("/v1/admin/login", {
      method: "POST",
      body: JSON.stringify({ username, password })
    });
    TOKEN = data.token;
    sessionStorage.setItem("cv_admin_token", TOKEN);
    $("login").hidden = true;
    $("app").hidden = false;
    await refresh();
  } catch (e) {
    $("loginMessage").textContent = e.message;
  }
}

function logout(revoke = true) {
  if (revoke && TOKEN) {
    fetch(API + "/v1/admin/logout", {
      method: "POST",
      headers: headers()
    }).catch(() => {});
  }
  TOKEN = "";
  sessionStorage.removeItem("cv_admin_token");
  $("login").hidden = false;
  $("app").hidden = true;
}

async function loadDashboard() {
  const d = await getJSON("/v1/admin/dashboard");
  $("pending").textContent = d.withdrawals.pending;
  $("approved").textContent = d.withdrawals.approved;
  $("rejected").textContent = d.withdrawals.rejected;
  $("gifts").textContent = d.completedGifts;
  $("purchases").textContent = d.creditedPurchases;
}

async function loadWithdrawals() {
  const status = $("status").value;
  const d = await getJSON("/v1/admin/withdrawals" +
    (status ? "?status=" + encodeURIComponent(status) : ""));
  const tbody = $("withdrawals");
  tbody.innerHTML = "";

  for (const w of d.withdrawals) {
    const tr = document.createElement("tr");
    const date = new Date(w.created_at).toLocaleString("pt-BR");
    const canReview = w.status === "pending";

    tr.innerHTML = `
      <td>${escapeHTML(w.withdrawal_id)}</td>
      <td>${escapeHTML(w.creator_id)}</td>
      <td>${Number(w.amount).toLocaleString("pt-BR")}</td>
      <td>${escapeHTML(w.payment_method)}</td>
      <td><span class="tag">${escapeHTML(w.status)}</span></td>
      <td>${date}</td>
      <td class="actions">
        ${canReview
          ? '<button class="approve" data-action="approve">Aprovar</button><button class="reject" data-action="reject">Rejeitar</button>'
          : "—"}
      </td>`;

    if (canReview) {
      tr.querySelector("[data-action=approve]").onclick =
        () => review(w.withdrawal_id, "approved");
      tr.querySelector("[data-action=reject]").onclick =
        () => review(w.withdrawal_id, "rejected");
    }
    tbody.appendChild(tr);
  }
}

async function review(id, status) {
  const reference = prompt(
    status === "approved"
      ? "Referência do pagamento (opcional):"
      : "Motivo/referência da rejeição (opcional):"
  );
  if (reference === null) return;

  try {
    const data = await getJSON(
      `/v1/admin/withdrawals/${encodeURIComponent(id)}/review`,
      {
        method: "POST",
        body: JSON.stringify({
          status,
          paymentReference: reference || null
        })
      }
    );
    showMessage(data.ok ? "Operação concluída." : "Falha.", true);
    await refresh();
  } catch (e) {
    showMessage(e.message, false);
  }
}

function showMessage(text, ok) {
  $("message").className = ok ? "success" : "error";
  $("message").textContent = text;
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

async function refresh() {
  try {
    await Promise.all([loadDashboard(), loadWithdrawals()]);
    showMessage("", true);
  } catch (e) {
    showMessage("Erro: " + e.message, false);
  }
}

$("loginButton").onclick = login;
$("logout").onclick = () => logout(true);
$("refresh").onclick = refresh;
$("status").onchange = loadWithdrawals;
$("password").addEventListener("keydown", e => {
  if (e.key === "Enter") login();
});

if (TOKEN) {
  getJSON("/v1/admin/me")
    .then(() => {
      $("login").hidden = true;
      $("app").hidden = false;
      refresh();
    })
    .catch(() => logout(false));
}
