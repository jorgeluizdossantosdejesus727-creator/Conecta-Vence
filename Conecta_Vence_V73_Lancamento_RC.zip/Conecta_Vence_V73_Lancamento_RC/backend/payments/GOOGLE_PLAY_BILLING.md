# V21 — Compras de moedas no Google Play

Para o app Android distribuído pela Google Play, compras de moedas virtuais são compras de bens digitais e, em regra, precisam usar o Google Play Billing. Consulte a política atual da Google Play antes do lançamento.

Fluxo de produção:
1. Criar os produtos de compra de moedas no Play Console.
2. Integrar Google Play Billing no módulo Android.
3. O app inicia a compra.
4. O Google Play confirma a compra.
5. O backend valida o purchase token.
6. O backend concede as moedas uma única vez.
7. A transação é gravada no banco.
8. Reembolsos/revogações devem retirar ou ajustar o saldo conforme as regras do produto.

Nunca conceder moedas somente porque o aplicativo recebeu um valor enviado pelo cliente.
