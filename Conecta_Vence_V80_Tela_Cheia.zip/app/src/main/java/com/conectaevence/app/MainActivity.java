package com.conectaevence.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private FrameLayout root;
    private final int BG = Color.rgb(5,8,18);
    private final int CARD = Color.rgb(12,19,34);
    private final int PINK = Color.rgb(255,25,145);
    private final int PURPLE = Color.rgb(130,55,255);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        hideSystemBars();
        showStart();
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private void base() {
        hideSystemBars();
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(radius); return g;
    }

    private GradientDrawable stroke(int color, int stroke, int strokeColor, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(radius); g.setStroke(stroke, strokeColor); return g;
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(16); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(10,0,10,0);
        if (primary) b.setBackground(bg(PINK, 60));
        else b.setBackground(stroke(Color.TRANSPARENT, 2, Color.rgb(120,80,255), 60));
        return b;
    }

    private void showStart() {
        base();
        // Use the approved visual as the complete initial artwork.
        ImageView art = new ImageView(this);
        art.setImageResource(R.drawable.splash_screen);
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(art, new FrameLayout.LayoutParams(-1,-1));

        // Transparent touch areas over the two buttons drawn in the artwork.
        View login = new View(this);
        login.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams lp1 = new FrameLayout.LayoutParams(-1, dp(72));
        lp1.leftMargin = dp(24); lp1.rightMargin = dp(24); lp1.gravity = Gravity.BOTTOM; lp1.bottomMargin = dp(115);
        login.setOnClickListener(v -> showLogin()); root.addView(login, lp1);

        View register = new View(this);
        register.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams lp2 = new FrameLayout.LayoutParams(-1, dp(72));
        lp2.leftMargin = dp(24); lp2.rightMargin = dp(24); lp2.gravity = Gravity.BOTTOM; lp2.bottomMargin = dp(28);
        register.setOnClickListener(v -> showRegister()); root.addView(register, lp2);
    }

    private LinearLayout page(String title) {
        base();
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18),dp(20),dp(18),dp(24));
        ScrollView scroll = new ScrollView(this); scroll.addView(page);
        root.addView(scroll, new FrameLayout.LayoutParams(-1,-1));
        TextView back = text("‹", 36, Color.WHITE, false);
        back.setGravity(Gravity.CENTER); back.setOnClickListener(v -> showStart());
        LinearLayout head = new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(back, new LinearLayout.LayoutParams(dp(50),dp(50)));
        TextView h = text(title, 25, Color.WHITE, true); head.addView(h);
        page.addView(head);
        return page;
    }

    private void showLogin() {
        LinearLayout page = page("Entrar");
        TextView sub = text("Entre na sua conta do Conecta & Vence.",14,Color.LTGRAY,false);
        page.addView(sub, margin(0,0,0,18));
        EditText email = field("E-mail"); page.addView(email, margin(0,0,0,10));
        EditText pass = field("Senha"); pass.setInputType(0x81); page.addView(pass, margin(0,0,0,16));
        Button enter = button("Entrar",true); page.addView(enter, margin(0,0,0,10));
        Button create = button("Criar conta",false); page.addView(create, margin(0,0,0,10));
        TextView msg = text("",13,Color.rgb(255,120,180),false); page.addView(msg);
        enter.setOnClickListener(v -> {
            if(email.getText().toString().trim().isEmpty() || pass.getText().toString().isEmpty()) {
                msg.setText("Preencha e-mail e senha."); return;
            }
            showHome();
        });
        create.setOnClickListener(v -> showRegister());
    }

    private void showRegister() {
        LinearLayout page = page("Criar conta");
        page.addView(text("Escolha seu perfil",18,Color.WHITE,true), margin(0,0,0,10));
        LinearLayout types = new LinearLayout(this); types.setOrientation(LinearLayout.HORIZONTAL);
        Button user = button("👩 Usuária",true); Button creator = button("🧑 Criador",false);
        types.addView(user,new LinearLayout.LayoutParams(0,dp(52),1));
        types.addView(creator,new LinearLayout.LayoutParams(0,dp(52),1));
        page.addView(types, margin(0,0,0,14));
        EditText name=field("Nome"); EditText email=field("E-mail"); EditText birth=field("Data de nascimento"); EditText pass=field("Crie uma senha"); pass.setInputType(0x81);
        page.addView(name,margin(0,0,0,9)); page.addView(email,margin(0,0,0,9)); page.addView(birth,margin(0,0,0,9)); page.addView(pass,margin(0,0,0,12));
        Button go=button("Continuar",true); page.addView(go,margin(0,0,0,12));
        TextView msg=text("",13,Color.rgb(255,120,180),false); page.addView(msg);
        go.setOnClickListener(v->{ if(name.getText().toString().trim().isEmpty()||email.getText().toString().trim().isEmpty()||pass.getText().toString().length()<6){msg.setText("Preencha os dados. A senha deve ter 6 caracteres ou mais.");return;} showHome();});
        user.setOnClickListener(v->{user.setBackground(bg(PINK,60));creator.setBackground(stroke(Color.TRANSPARENT,2,Color.rgb(120,80,255),60));});
        creator.setOnClickListener(v->{creator.setBackground(bg(PINK,60));user.setBackground(stroke(Color.TRANSPARENT,2,Color.rgb(120,80,255),60));});
    }

    private EditText field(String hint){
        EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(Color.rgb(150,158,175)); e.setTextColor(Color.WHITE); e.setTextSize(16); e.setSingleLine(true); e.setPadding(dp(15),0,dp(15),0); e.setBackground(stroke(CARD,1,Color.rgb(48,66,94),30)); return e;
    }

    private void showHome(){
        base();
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(dp(16),dp(18),dp(16),dp(90));
        ScrollView scroll=new ScrollView(this); scroll.addView(page); root.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand=text("💗 Conecta & Vence",22,Color.WHITE,true); top.addView(brand,new LinearLayout.LayoutParams(0,dp(50),1));
        TextView coin=text("🪙 2.350",14,Color.WHITE,true); coin.setPadding(dp(12),dp(8),dp(12),dp(8)); coin.setBackground(stroke(CARD,1,Color.rgb(70,92,120),40)); top.addView(coin);
        page.addView(top);
        page.addView(text("Início",28,Color.WHITE,true),margin(0,10,0,4));
        page.addView(text("Criadores ao vivo agora",14,Color.rgb(170,180,195),false),margin(0,0,0,12));
        LinearLayout live=new LinearLayout(this); live.setOrientation(LinearLayout.VERTICAL); live.setPadding(dp(14),dp(14),dp(14),dp(14)); live.setBackground(bg(Color.rgb(18,27,48),30));
        TextView tag=text("🔴 AO VIVO   👁 1,2 mil",13,Color.WHITE,true); live.addView(tag); live.addView(text("Bate-papo, jogos e muito mais",20,Color.WHITE,true),margin(0,12,0,5)); live.addView(text("Encontre criadores, acompanhe lives e envie presentes.",14,Color.rgb(190,198,214),false),margin(0,0,0,12));
        Button watch=button("Assistir agora",true); watch.setOnClickListener(v->showLive("Live em destaque")); live.addView(watch,new LinearLayout.LayoutParams(-1,dp(48))); page.addView(live,margin(0,0,0,18));
        page.addView(text("Em destaque",19,Color.WHITE,true),margin(0,0,0,10));
        LinearLayout cards=new LinearLayout(this); cards.setOrientation(LinearLayout.HORIZONTAL);
        String[] names={"Lary_Silva","Lucas_Oficial","AnaGamer"}; for(String n:names){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(10),dp(10),dp(10),dp(10));c.setBackground(stroke(Color.rgb(12,20,35),1,Color.rgb(47,67,98),22));c.addView(text("👤",34,Color.WHITE,false),new LinearLayout.LayoutParams(-1,dp(60)));c.addView(text(n,13,Color.WHITE,true));c.addView(text("🔴 AO VIVO",11,PINK,true)); c.setOnClickListener(v->showLive(n)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(145),1);cp.setMargins(0,0,dp(7),0);cards.addView(c,cp);} page.addView(cards);
        page.addView(text("Novos criadores",19,Color.WHITE,true),margin(0,18,0,8)); page.addView(text("👩‍🦰    🧑‍🎤    👩    🧔    👨‍🦱",28,Color.WHITE,false));
        addBottomNav();
    }

    private void addBottomNav(){
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.rgb(10,15,27));
        String[] labels={"⌂\nInício","▣\nAo vivo","◌\nConversas","♧\nFazenda","♙\nPerfil"};
        for(int i=0;i<labels.length;i++){
            final int index=i;
            TextView t=text(labels[i],11,Color.LTGRAY,false); t.setGravity(Gravity.CENTER);
            t.setPadding(0,dp(6),0,dp(4));
            t.setOnClickListener(v->{
                if(index==0) showHome();
                else if(index==1) showLive("Ao vivo agora");
                else if(index==2) showConversations();
                else if(index==3) showFarm();
                else showProfile();
            });
            nav.addView(t,new LinearLayout.LayoutParams(0,dp(68),1));
        }
        FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(-1,dp(72),Gravity.BOTTOM); root.addView(nav,p);
    }

    private void showLive(String creator){
        LinearLayout page=page("Ao vivo");
        TextView live=text("🔴 AO VIVO",14,PINK,true); page.addView(live,margin(0,8,0,10));
        page.addView(text(creator,26,Color.WHITE,true),margin(0,0,0,8));
        TextView box=text("🎥\n\nTransmissão ao vivo de demonstração\n\n💬 O chat aparecerá aqui.",18,Color.WHITE,false); box.setGravity(Gravity.CENTER); box.setPadding(dp(18),dp(30),dp(18),dp(30)); box.setBackground(bg(Color.rgb(18,27,48),28)); page.addView(box,margin(0,0,0,14));
        Button gift=button("🎁 Enviar presente",true); gift.setOnClickListener(v->Toast.makeText(this,"Escolha um presente",Toast.LENGTH_SHORT).show()); page.addView(gift,margin(0,0,0,10));
        Button back=button("Voltar para Início",false); back.setOnClickListener(v->showHome()); page.addView(back);
    }

    private void showConversations(){
        LinearLayout page=page("Conversas");
        page.addView(text("Suas conversas",20,Color.WHITE,true),margin(0,10,0,12));
        String[] chats={"Lary_Silva","Lucas_Oficial","AnaGamer"};
        for(String n:chats){ Button b=button("💬  "+n+"\nToque para abrir a conversa",false); b.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT); b.setOnClickListener(v->Toast.makeText(this,"Conversa com "+n,Toast.LENGTH_SHORT).show()); page.addView(b,margin(0,0,0,10)); }
    }

    private void showFarm(){
        LinearLayout page=page("Fazenda");
        page.addView(text("🌱 Sua fazenda",25,Color.WHITE,true),margin(0,10,0,8));
        page.addView(text("Plante, colha feijões e troque por recompensas.",15,Color.LTGRAY,false),margin(0,0,0,18));
        TextView beans=text("🫘 1.250 feijões",22,Color.WHITE,true); beans.setGravity(Gravity.CENTER); beans.setPadding(dp(10),dp(24),dp(10),dp(24)); beans.setBackground(bg(Color.rgb(18,27,48),28)); page.addView(beans,margin(0,0,0,14));
        Button harvest=button("🌾 Colher feijões",true); harvest.setOnClickListener(v->Toast.makeText(this,"Colheita realizada!",Toast.LENGTH_SHORT).show()); page.addView(harvest);
    }

    private void showProfile(){
        LinearLayout page=page("Meu Perfil");
        TextView avatar=text("👤",60,Color.WHITE,false); avatar.setGravity(Gravity.CENTER); page.addView(avatar,margin(0,12,0,8));
        TextView name=text("Meu perfil",24,Color.WHITE,true); name.setGravity(Gravity.CENTER); page.addView(name,margin(0,0,0,18));
        page.addView(text("Seguidores   0        Seguindo   0",16,Color.LTGRAY,false),margin(0,0,0,18));
        Button wallet=button("💰 Carteira e ganhos",false); wallet.setOnClickListener(v->Toast.makeText(this,"Carteira de demonstração",Toast.LENGTH_SHORT).show()); page.addView(wallet,margin(0,0,0,10));
        Button settings=button("⚙ Configurações",false); settings.setOnClickListener(v->Toast.makeText(this,"Configurações",Toast.LENGTH_SHORT).show()); page.addView(settings);
    }

    private LinearLayout.LayoutParams margin(int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
}
