package com.conectaevencer.billing

import android.app.Activity
import com.android.billingclient.api.*

class PlayBillingManager(
    private val activity: Activity,
    private val onPurchaseToken: (String, String) -> Unit
) : PurchasesUpdatedListener {

    private val billingClient = BillingClient.newBuilder(activity)
        .setListener(this)
        .enablePendingPurchases()
        .enableAutoServiceReconnection()
        .build()

    fun connect(onReady: () -> Unit) {
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) onReady()
            }
            override fun onBillingServiceDisconnected() = Unit
        })
    }

    fun queryProducts(callback: (List<ProductDetails>) -> Unit) {
        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(
                BillingCatalog.products.map {
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(it)
                        .setProductType(BillingClient.ProductType.INAPP)
                        .build()
                }
            ).build()
        billingClient.queryProductDetailsAsync(params) { _, result ->
            callback(result.productDetailsList)
        }
    }

    fun buy(product: ProductDetails) {
        val offer = product.oneTimePurchaseOfferDetailsList?.firstOrNull() ?: return
        val productParams = BillingFlowParams.ProductDetailsParams.newBuilder()
            .setProductDetails(product)
            .setOfferToken(offer.offerToken)
            .build()
        billingClient.launchBillingFlow(
            activity,
            BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(listOf(productParams))
                .build()
        )
    }

    override fun onPurchasesUpdated(
        result: BillingResult,
        purchases: MutableList<Purchase>?
    ) {
        if (result.responseCode == BillingClient.BillingResponseCode.OK) {
            purchases.orEmpty().forEach { purchase ->
                purchase.products.forEach { productId ->
                    onPurchaseToken(purchase.purchaseToken, productId)
                }
            }
        }
    }
}
