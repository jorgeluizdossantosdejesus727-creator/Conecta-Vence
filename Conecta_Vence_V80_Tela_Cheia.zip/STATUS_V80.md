# Status V80

- VersionCode: 80
- VersionName: 1.0.9
- Tela cheia imersiva ativada.
- Barras do sistema ocultadas durante o uso.
