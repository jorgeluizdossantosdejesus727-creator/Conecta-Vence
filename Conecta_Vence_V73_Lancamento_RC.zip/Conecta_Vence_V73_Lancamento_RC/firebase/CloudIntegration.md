# V28 — Integração dos dados do aplicativo

A camada de dados agora possui um repositório de carteira para:
- feijões;
- diamantes;
- presentes enviados;
- ganhos em centavos;
- histórico de movimentações.

Regra importante:
O cliente não deve ser a autoridade final sobre dinheiro real. Para compras,
ganhos e saques, os valores financeiros devem ser calculados/confirmados pelo
backend. Esta classe é a camada de persistência do aplicativo, não substitui
as validações do servidor.

Fluxo:
Login Firebase → UID → Firestore → Perfil/Carteira/Histórico.

Para produção:
- configurar `google-services.json`;
- conectar os métodos às telas;
- proteger campos financeiros com regras adequadas;
- para moedas compradas, usar o backend V25/V24 como autoridade;
- criar Cloud Functions/backend para operações financeiras.
