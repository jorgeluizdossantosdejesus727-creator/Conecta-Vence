# Conecta & Vence V79

Correção da navegação da tela inicial. Os itens Início, Ao vivo, Conversas, Fazenda e Perfil agora respondem ao toque; o botão Assistir agora e os criadores em destaque também abrem telas funcionais de demonstração.
