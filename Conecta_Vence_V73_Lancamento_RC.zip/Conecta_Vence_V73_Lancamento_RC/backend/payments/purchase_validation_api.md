# V23 — Validação de compra

Endpoint sugerido:
POST /api/purchases/google-play/validate

Entrada:
- userId
- productId
- purchaseToken

O servidor deve:
1. autenticar o usuário;
2. validar o purchaseToken com o Google Play Developer API;
3. confirmar productId e status;
4. verificar se o token já foi processado;
5. registrar a transação;
6. creditar moedas somente uma vez;
7. devolver o novo saldo.

Nunca confiar no saldo enviado pelo aplicativo.
