# V51 — Ledger persistente

Cada crédito de moedas gera uma entrada permanente no `wallet_ledger`.

A regra principal é:

`purchase_token` é único.

Assim, uma mesma compra não pode criar dois créditos no ledger.

O saldo atual fica em `wallets`, enquanto o histórico fica no ledger. Em produção, o backend deve usar um banco gerenciado e autenticação forte, além da validação oficial da compra pela Google Play Developer API.

A documentação atual do Google recomenda manter o gerenciamento do estado da compra no backend e sincronizá-lo com o Google Play. Também recomenda processar RTDNs de forma idempotente, evitando repetir o processamento de `messageId`s duplicados. citeturn0search2turn0search1
