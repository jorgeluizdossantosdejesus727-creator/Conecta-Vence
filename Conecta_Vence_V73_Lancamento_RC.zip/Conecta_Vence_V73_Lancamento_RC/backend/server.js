import express from "express";
import Database from "better-sqlite3";
import { google } from "googleapis";

const app = express();
app.use(express.json({ limit: "256kb" }));

const PORT = process.env.PORT || 8080;
const PACKAGE_NAME = process.env.PACKAGE_NAME || "COM.EXEMPLO.SUBSTITUIR";
const db = new Database(process.env.DB_PATH || "./conecta_vence.sqlite");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS wallets (
  user_id TEXT PRIMARY KEY,
  coins INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS wallet_ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  purchase_token TEXT,
  type TEXT NOT NULL,
  coins_delta INTEGER NOT NULL,
  balance_after INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS purchases (
  purchase_token TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  product_id TEXT NOT NULL,
  coins INTEGER NOT NULL,
  status TEXT NOT NULL,
  order_id TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS rtdn_messages (
  message_id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  purchase_token TEXT,
  created_at INTEGER NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_ledger_purchase_credit
ON wallet_ledger(purchase_token)
WHERE purchase_token IS NOT NULL AND type = 'purchase_credit';
`);

const PRODUCTS = Object.freeze({
  coins_1000: 1000,
  coins_2500: 2500,
  coins_6000: 6000
});

const now = () => Date.now();

function googleAuth() {
  if (!process.env.GOOGLE_SERVICE_ACCOUNT_JSON) return null;
  return new google.auth.GoogleAuth({
    credentials: JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_JSON),
    scopes: ["https://www.googleapis.com/auth/androidpublisher"]
  });
}

async function getGooglePurchase(productId, purchaseToken) {
  const auth = googleAuth();
  if (!auth) return { configured: false, verified: false };

  const publisher = google.androidpublisher({ version: "v3", auth });
  const response = await publisher.purchases.products.get({
    packageName: PACKAGE_NAME,
    productId,
    token: purchaseToken
  });

  const data = response.data || {};
  return {
    configured: true,
    verified: Number(data.purchaseState) === 0,
    acknowledged: Number(data.acknowledgementState) === 1,
    consumptionState: Number(data.consumptionState),
    orderId: data.orderId || null
  };
}

async function consumeGooglePurchase(productId, purchaseToken) {
  const auth = googleAuth();
  if (!auth) return false;

  const publisher = google.androidpublisher({ version: "v3", auth });
  await publisher.purchases.products.consume({
    packageName: PACKAGE_NAME,
    productId,
    token: purchaseToken
  });
  return true;
}

/*
 * ATOMIC:
 * purchase + wallet + ledger are updated in one database transaction.
 * The unique purchase_token constraint makes the credit idempotent.
 */
const creditTransaction = db.transaction(
  ({ userId, productId, purchaseToken, orderId }) => {
    const coins = PRODUCTS[productId];
    if (!coins) throw new Error("Product ID não cadastrado.");

    const existing = db.prepare(
      "SELECT status FROM purchases WHERE purchase_token = ?"
    ).get(purchaseToken);

    if (existing?.status === "credited") {
      return { credited: false, balance: getBalance(userId) };
    }

    const timestamp = now();

    db.prepare(`
      INSERT INTO wallets(user_id, coins, updated_at)
      VALUES (?, 0, ?)
      ON CONFLICT(user_id) DO NOTHING
    `).run(userId, timestamp);

    const current = getBalance(userId);
    const balance = current + coins;

    db.prepare(`
      INSERT INTO purchases
        (purchase_token,user_id,product_id,coins,status,order_id,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?)
      ON CONFLICT(purchase_token) DO UPDATE SET
        user_id=excluded.user_id,
        product_id=excluded.product_id,
        coins=excluded.coins,
        status='credited',
        order_id=excluded.order_id,
        updated_at=excluded.updated_at
    `).run(
      purchaseToken, userId, productId, coins,
      "credited", orderId, timestamp, timestamp
    );

    db.prepare(
      "UPDATE wallets SET coins=?, updated_at=? WHERE user_id=?"
    ).run(balance, timestamp, userId);

    db.prepare(`
      INSERT INTO wallet_ledger
        (user_id,purchase_token,type,coins_delta,balance_after,created_at)
      VALUES (?,?,?,?,?,?)
    `).run(
      userId, purchaseToken, "purchase_credit",
      coins, balance, timestamp
    );

    return { credited: true, balance };
  }
);

function getBalance(userId) {
  return db.prepare(
    "SELECT coins FROM wallets WHERE user_id = ?"
  ).get(userId)?.coins ?? 0;
}

async function processVerifiedPurchase({ userId, productId, purchaseToken, orderId }) {
  const result = creditTransaction({
    userId, productId, purchaseToken, orderId
  });

  /*
   * Consumable coins: after entitlement is recorded, consume the
   * Play purchase so the same product can be bought again.
   */
  if (result.credited) {
    try {
      await consumeGooglePurchase(productId, purchaseToken);
    } catch (error) {
      // Entitlement remains recorded. A retry worker should consume later.
      console.error("Consume pendente:", error.message);
    }
  }

  return result;
}


/* =========================
   V54 — PRESENTES E GANHOS
   ========================= */

db.exec(`
CREATE TABLE IF NOT EXISTS gifts (
  gift_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  coin_cost INTEGER NOT NULL,
  creator_value INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS creator_wallets (
  creator_id TEXT PRIMARY KEY,
  balance INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS creator_ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  creator_id TEXT NOT NULL,
  sender_id TEXT NOT NULL,
  gift_id TEXT NOT NULL,
  coins_spent INTEGER NOT NULL,
  creator_value INTEGER NOT NULL,
  event_id TEXT NOT NULL UNIQUE,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS gift_events (
  event_id TEXT PRIMARY KEY,
  sender_id TEXT NOT NULL,
  creator_id TEXT NOT NULL,
  gift_id TEXT NOT NULL,
  coin_cost INTEGER NOT NULL,
  creator_value INTEGER NOT NULL,
  status TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
`);

const GIFTS = Object.freeze({
  heart:  { name: "Coração", coinCost: 10,  creatorValue: 7 },
  rose:   { name: "Rosa",    coinCost: 25,  creatorValue: 18 },
  star:   { name: "Estrela", coinCost: 50,  creatorValue: 35 },
  trophy: { name: "Troféu",  coinCost: 100, creatorValue: 70 }
});

for (const [giftId, gift] of Object.entries(GIFTS)) {
  db.prepare(`
    INSERT INTO gifts(gift_id,name,coin_cost,creator_value)
    VALUES(?,?,?,?)
    ON CONFLICT(gift_id) DO UPDATE SET
      name=excluded.name,
      coin_cost=excluded.coin_cost,
      creator_value=excluded.creator_value
  `).run(giftId, gift.name, gift.coinCost, gift.creatorValue);
}

function debitGiftTransaction({ senderId, creatorId, giftId, eventId }) {
  const gift = GIFTS[giftId];
  if (!gift) throw new Error("Presente não cadastrado.");
  if (!senderId || !creatorId || !eventId) throw new Error("Dados incompletos.");
  if (senderId === creatorId) throw new Error("Não é permitido enviar presente para si mesmo.");

  return db.transaction(() => {
    const duplicate = db.prepare(
      "SELECT status FROM gift_events WHERE event_id = ?"
    ).get(eventId);

    if (duplicate) {
      return { duplicate: true };
    }

    const senderBalance = getBalance(senderId);
    if (senderBalance < gift.coinCost) {
      throw new Error("Saldo de moedas insuficiente.");
    }

    const timestamp = now();

    db.prepare(`
      INSERT INTO wallets(user_id,coins,updated_at)
      VALUES(?,?,?)
      ON CONFLICT(user_id) DO NOTHING
    `).run(senderId, senderBalance, timestamp);

    const newSenderBalance = senderBalance - gift.coinCost;

    db.prepare(
      "UPDATE wallets SET coins=?, updated_at=? WHERE user_id=?"
    ).run(newSenderBalance, timestamp, senderId);

    db.prepare(`
      INSERT INTO wallet_ledger
        (user_id,purchase_token,type,coins_delta,balance_after,created_at)
      VALUES (?,?,?,?,?,?)
    `).run(
      senderId, null, "gift_debit",
      -gift.coinCost, newSenderBalance, timestamp
    );

    db.prepare(`
      INSERT INTO creator_wallets(creator_id,balance,updated_at)
      VALUES(?,?,?)
      ON CONFLICT(creator_id) DO NOTHING
    `).run(creatorId, 0, timestamp);

    const creatorBalance = db.prepare(
      "SELECT balance FROM creator_wallets WHERE creator_id=?"
    ).get(creatorId)?.balance ?? 0;

    const newCreatorBalance = creatorBalance + gift.creatorValue;

    db.prepare(
      "UPDATE creator_wallets SET balance=?, updated_at=? WHERE creator_id=?"
    ).run(newCreatorBalance, timestamp, creatorId);

    db.prepare(`
      INSERT INTO creator_ledger
        (creator_id,sender_id,gift_id,coins_spent,creator_value,event_id,created_at)
      VALUES(?,?,?,?,?,?,?)
    `).run(
      creatorId, senderId, giftId,
      gift.coinCost, gift.creatorValue, eventId, timestamp
    );

    db.prepare(`
      INSERT INTO gift_events
        (event_id,sender_id,creator_id,gift_id,coin_cost,creator_value,status,created_at)
      VALUES(?,?,?,?,?,?,?,?)
    `).run(
      eventId, senderId, creatorId, giftId,
      gift.coinCost, gift.creatorValue, "completed", timestamp
    );

    return {
      duplicate: false,
      senderCoins: newSenderBalance,
      creatorBalance: newCreatorBalance,
      gift
    };
  })();
}

app.get("/v1/gifts", (_req, res) => {
  res.json({
    ok: true,
    gifts: Object.entries(GIFTS).map(([id, g]) => ({
      id,
      name: g.name,
      coinCost: g.coinCost,
      creatorValue: g.creatorValue
    }))
  });
});

app.post("/v1/gifts/send", (req, res) => {
  try {
    const { senderId, creatorId, giftId, eventId } = req.body ?? {};

    if (!senderId || !creatorId || !giftId || !eventId) {
      return res.status(400).json({
        ok: false,
        error: "senderId, creatorId, giftId e eventId são obrigatórios."
      });
    }

    const result = debitGiftTransaction({
      senderId, creatorId, giftId, eventId
    });

    if (result.duplicate) {
      return res.status(409).json({
        ok: false,
        error: "Evento de presente já processado."
      });
    }

    res.json({
      ok: true,
      status: "completed",
      senderCoins: result.senderCoins,
      creatorBalance: result.creatorBalance,
      gift: result.gift
    });
  } catch (error) {
    res.status(400).json({
      ok: false,
      error: error.message || "Não foi possível enviar o presente."
    });
  }
});

app.get("/v1/creator/:creatorId/balance", (req, res) => {
  const row = db.prepare(
    "SELECT balance FROM creator_wallets WHERE creator_id=?"
  ).get(req.params.creatorId);

  res.json({
    creatorId: req.params.creatorId,
    balance: row?.balance ?? 0
  });
});


/* =========================
   V55 — SAQUE + HISTÓRICO
   ========================= */

db.exec(`
CREATE TABLE IF NOT EXISTS creator_withdrawals (
  withdrawal_id TEXT PRIMARY KEY,
  creator_id TEXT NOT NULL,
  amount INTEGER NOT NULL,
  status TEXT NOT NULL,
  payment_method TEXT NOT NULL,
  payment_reference TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_creator_withdrawals_creator
ON creator_withdrawals(creator_id, created_at);

CREATE INDEX IF NOT EXISTS idx_creator_ledger_creator
ON creator_ledger(creator_id, created_at);
`);

const MIN_WITHDRAWAL = 1000; // unidade interna de ganho; ajustar antes da produção.

function requestCreatorWithdrawal({ creatorId, amount, paymentMethod, withdrawalId }) {
  if (!creatorId || !withdrawalId || !paymentMethod) {
    throw new Error("Dados do saque incompletos.");
  }
  if (!Number.isInteger(amount) || amount <= 0) {
    throw new Error("Valor de saque inválido.");
  }
  if (amount < MIN_WITHDRAWAL) {
    throw new Error(`Saque mínimo: ${MIN_WITHDRAWAL}.`);
  }

  return db.transaction(() => {
    const duplicate = db.prepare(
      "SELECT status FROM creator_withdrawals WHERE withdrawal_id=?"
    ).get(withdrawalId);

    if (duplicate) {
      return { duplicate: true, status: duplicate.status };
    }

    const wallet = db.prepare(
      "SELECT balance FROM creator_wallets WHERE creator_id=?"
    ).get(creatorId);

    const balance = wallet?.balance ?? 0;
    if (balance < amount) {
      throw new Error("Saldo de ganhos insuficiente.");
    }

    const timestamp = now();

    db.prepare(
      "UPDATE creator_wallets SET balance=?, updated_at=? WHERE creator_id=?"
    ).run(balance - amount, timestamp, creatorId);

    db.prepare(`
      INSERT INTO creator_withdrawals
        (withdrawal_id,creator_id,amount,status,payment_method,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?)
    `).run(
      withdrawalId, creatorId, amount, "pending",
      paymentMethod, timestamp, timestamp
    );

    db.prepare(`
      INSERT INTO creator_ledger
        (creator_id,sender_id,gift_id,coins_spent,creator_value,event_id,created_at)
      VALUES (?,?,?,?,?,?,?)
    `).run(
      creatorId, "SYSTEM", "withdrawal",
      0, -amount, withdrawalId, timestamp
    );

    return {
      duplicate: false,
      status: "pending",
      remainingBalance: balance - amount
    };
  })();
}

app.post("/v1/creator/withdrawals", (req, res) => {
  try {
    const { creatorId, amount, paymentMethod, withdrawalId } = req.body ?? {};

    const result = requestCreatorWithdrawal({
      creatorId,
      amount,
      paymentMethod,
      withdrawalId
    });

    if (result.duplicate) {
      return res.status(409).json({
        ok: false,
        error: "Solicitação de saque já registrada.",
        status: result.status
      });
    }

    res.json({
      ok: true,
      status: result.status,
      remainingBalance: result.remainingBalance
    });
  } catch (error) {
    res.status(400).json({
      ok: false,
      error: error.message || "Não foi possível solicitar o saque."
    });
  }
});

app.get("/v1/creator/:creatorId/financial-history", (req, res) => {
  const creatorId = req.params.creatorId;

  const withdrawals = db.prepare(`
    SELECT withdrawal_id, amount, status, payment_method,
           payment_reference, created_at, updated_at
    FROM creator_withdrawals
    WHERE creator_id=?
    ORDER BY created_at DESC
  `).all(creatorId);

  const earnings = db.prepare(`
    SELECT id, sender_id, gift_id, creator_value, event_id, created_at
    FROM creator_ledger
    WHERE creator_id=?
    ORDER BY created_at DESC
  `).all(creatorId);

  const balance = db.prepare(
    "SELECT balance FROM creator_wallets WHERE creator_id=?"
  ).get(creatorId)?.balance ?? 0;

  res.json({
    ok: true,
    balance,
    earnings,
    withdrawals
  });
});


/* =========================
   V56 — PAINEL ADMINISTRATIVO
   ========================= */

/* =========================
   V58 — AUTH ADMINISTRATIVO
   ========================= */

import crypto from "node:crypto";

const ADMIN_USER = process.env.ADMIN_USER;
const ADMIN_PASSWORD_HASH = process.env.ADMIN_PASSWORD_HASH;
const SESSION_SECRET = process.env.ADMIN_SESSION_SECRET;

const sessions = new Map();
const SESSION_TTL_MS = 8 * 60 * 60 * 1000;

function hashPassword(password) {
  return crypto
    .createHash("sha256")
    .update(String(password))
    .digest("hex");
}

function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

function signSession(sessionId) {
  return crypto
    .createHmac("sha256", SESSION_SECRET || "CHANGE_ME")
    .update(sessionId)
    .digest("hex");
}

function parseSession(req) {
  const raw = req.header("authorization") || "";
  if (!raw.startsWith("Bearer ")) return null;

  const token = raw.slice(7);
  const dot = token.indexOf(".");
  if (dot < 1) return null;

  const sessionId = token.slice(0, dot);
  const signature = token.slice(dot + 1);

  if (!safeEqual(signature, signSession(sessionId))) return null;

  const session = sessions.get(sessionId);
  if (!session || session.expiresAt < now()) {
    sessions.delete(sessionId);
    return null;
  }

  return session;
}

function requireAdmin(req, res, next) {
  const session = parseSession(req);
  if (!session) {
    return res.status(401).json({
      ok: false,
      error: "Sessão administrativa inválida ou expirada."
    });
  }
  req.admin = session;
  next();
}

app.post("/v1/admin/login", (req, res) => {
  try {
    const { username, password } = req.body ?? {};

    if (!ADMIN_USER || !ADMIN_PASSWORD_HASH || !SESSION_SECRET) {
      return res.status(503).json({
        ok: false,
        error: "Autenticação administrativa não configurada."
      });
    }

    if (!safeEqual(username, ADMIN_USER) ||
        !safeEqual(hashPassword(password), ADMIN_PASSWORD_HASH)) {
      return res.status(401).json({
        ok: false,
        error: "Usuário ou senha inválidos."
      });
    }

    const sessionId = crypto.randomBytes(32).toString("hex");
    const expiresAt = now() + SESSION_TTL_MS;

    sessions.set(sessionId, {
      username: ADMIN_USER,
      expiresAt
    });

    const token = `${sessionId}.${signSession(sessionId)}`;

    res.json({
      ok: true,
      token,
      expiresAt
    });
  } catch {
    res.status(500).json({ ok: false, error: "Falha no login." });
  }
});

app.post("/v1/admin/logout", requireAdmin, (req, res) => {
  const raw = req.header("authorization") || "";
  const token = raw.slice(7);
  const dot = token.indexOf(".");
  if (dot > 0) sessions.delete(token.slice(0, dot));
  res.json({ ok: true });
});

app.get("/v1/admin/me", requireAdmin, (req, res) => {
  res.json({
    ok: true,
    username: req.admin.username,
    expiresAt: req.admin.expiresAt
  });
});


app.get("/v1/admin/withdrawals", requireAdmin, (req, res) => {
  const status = req.query.status;

  let rows;
  if (status) {
    rows = db.prepare(`
      SELECT withdrawal_id, creator_id, amount, status,
             payment_method, payment_reference,
             created_at, updated_at
      FROM creator_withdrawals
      WHERE status=?
      ORDER BY created_at DESC
    `).all(status);
  } else {
    rows = db.prepare(`
      SELECT withdrawal_id, creator_id, amount, status,
             payment_method, payment_reference,
             created_at, updated_at
      FROM creator_withdrawals
      ORDER BY created_at DESC
    `).all();
  }

  res.json({ ok: true, withdrawals: rows });
});

const updateWithdrawal = db.transaction(
  ({ withdrawalId, newStatus, paymentReference }) => {
    const withdrawal = db.prepare(`
      SELECT withdrawal_id, creator_id, amount, status
      FROM creator_withdrawals
      WHERE withdrawal_id=?
    `).get(withdrawalId);

    if (!withdrawal) throw new Error("Saque não encontrado.");

    if (withdrawal.status !== "pending") {
      throw new Error("Somente saques pendentes podem ser analisados.");
    }

    const timestamp = now();

    if (newStatus === "approved") {
      db.prepare(`
        UPDATE creator_withdrawals
        SET status='approved', payment_reference=?, updated_at=?
        WHERE withdrawal_id=?
      `).run(paymentReference || null, timestamp, withdrawalId);

      return { status: "approved", refunded: false };
    }

    if (newStatus === "rejected") {
      db.prepare(`
        UPDATE creator_withdrawals
        SET status='rejected', payment_reference=?, updated_at=?
        WHERE withdrawal_id=?
      `).run(paymentReference || null, timestamp, withdrawalId);

      db.prepare(`
        INSERT INTO creator_ledger
          (creator_id,sender_id,gift_id,coins_spent,creator_value,event_id,created_at)
        VALUES (?,?,?,?,?,?,?)
      `).run(
        withdrawal.creator_id,
        "SYSTEM",
        "withdrawal_refund",
        0,
        withdrawal.amount,
        `${withdrawalId}:refund`,
        timestamp
      );

      db.prepare(`
        UPDATE creator_wallets
        SET balance=balance+?, updated_at=?
        WHERE creator_id=?
      `).run(withdrawal.amount, timestamp, withdrawal.creator_id);

      return { status: "rejected", refunded: true };
    }

    throw new Error("Status administrativo inválido.");
  }
);

app.post("/v1/admin/withdrawals/:withdrawalId/review", requireAdmin, (req, res) => {
  try {
    const { status, paymentReference } = req.body ?? {};

    const result = updateWithdrawal({
      withdrawalId: req.params.withdrawalId,
      newStatus: status,
      paymentReference
    });

    res.json({
      ok: true,
      status: result.status,
      refunded: result.refunded
    });
  } catch (error) {
    res.status(400).json({
      ok: false,
      error: error.message || "Não foi possível analisar o saque."
    });
  }
});

app.get("/v1/admin/dashboard", requireAdmin, (_req, res) => {
  const pending = db.prepare(
    "SELECT COUNT(*) AS count FROM creator_withdrawals WHERE status='pending'"
  ).get().count;

  const approved = db.prepare(
    "SELECT COUNT(*) AS count FROM creator_withdrawals WHERE status='approved'"
  ).get().count;

  const rejected = db.prepare(
    "SELECT COUNT(*) AS count FROM creator_withdrawals WHERE status='rejected'"
  ).get().count;

  const gifts = db.prepare(
    "SELECT COUNT(*) AS count FROM gift_events WHERE status='completed'"
  ).get().count;

  const purchases = db.prepare(
    "SELECT COUNT(*) AS count FROM purchases WHERE status='credited'"
  ).get().count;

  res.json({
    ok: true,
    withdrawals: { pending, approved, rejected },
    completedGifts: gifts,
    creditedPurchases: purchases
  });
});


/* =========================
   V59 — PIX / PAGAR.ME
   ========================= */

const PAGARME_API_URL = process.env.PAGARME_API_URL || "https://api.pagar.me/core/v5";
const PAGARME_SECRET_KEY = process.env.PAGARME_SECRET_KEY || "";

async function pagarmeRequest(path, method = "GET", body = null) {
  if (!PAGARME_SECRET_KEY) {
    throw new Error("PAGARME_SECRET_KEY não configurada.");
  }

  const headers = {
    "Authorization": `Basic ${Buffer.from(PAGARME_SECRET_KEY + ":").toString("base64")}`,
    "Content-Type": "application/json",
    "User-Agent": "conecta-vence/59"
  };

  const response = await fetch(`${PAGARME_API_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(
      `Pagar.me HTTP ${response.status}: ${data.message || "erro na API"}`
    );
  }

  return data;
}

/*
 * Production design:
 * - The creator must have a Pagar.me recipient.
 * - KYC/recipient status must be validated by the payment provider.
 * - The app's internal wallet is not itself a bank account.
 * - The provider is responsible for the actual bank transfer.
 */
app.post("/v1/admin/withdrawals/:withdrawalId/pay", requireAdmin, async (req, res) => {
  try {
    const withdrawal = db.prepare(`
      SELECT withdrawal_id, creator_id, amount, status, payment_method, payment_reference
      FROM creator_withdrawals
      WHERE withdrawal_id=?
    `).get(req.params.withdrawalId);

    if (!withdrawal) {
      return res.status(404).json({ ok: false, error: "Saque não encontrado." });
    }

    if (withdrawal.status !== "approved") {
      return res.status(400).json({
        ok: false,
        error: "O saque precisa estar aprovado antes do pagamento."
      });
    }

    const recipientId = req.body?.recipientId ||
      db.prepare(
        "SELECT recipient_id FROM creator_payout_profiles WHERE creator_id=?"
      ).get(withdrawal.creator_id)?.recipient_id;

    if (!recipientId) {
      return res.status(400).json({
        ok: false,
        error: "Recebedor Pagar.me não cadastrado para este criador."
      });
    }

    // Pagar.me expects monetary amounts in cents.
    const amountInCents = Number(withdrawal.amount);

    if (!Number.isSafeInteger(amountInCents) || amountInCents <= 0) {
      return res.status(400).json({
        ok: false,
        error: "Valor do saque inválido."
      });
    }

    const transfer = await pagarmeRequest("/transfers", "POST", {
      amount: amountInCents,
      recipient_id: recipientId,
      metadata: {
        withdrawal_id: withdrawal.withdrawal_id,
        creator_id: withdrawal.creator_id
      }
    });

    const timestamp = now();

    db.prepare(`
      UPDATE creator_withdrawals
      SET status='processing',
          payment_reference=?,
          updated_at=?
      WHERE withdrawal_id=?
    `).run(
      String(transfer.id || withdrawal.payment_reference || ""),
      timestamp,
      withdrawal.withdrawal_id
    );

    res.json({
      ok: true,
      status: "processing",
      provider: "pagarme",
      transferId: transfer.id || null
    });
  } catch (error) {
    res.status(502).json({
      ok: false,
      error: error.message || "Falha ao solicitar pagamento PIX."
    });
  }
});

app.post("/v1/webhooks/pagarme", async (req, res) => {
  /*
   * Do not trust webhook payload blindly.
   * Production must validate the provider's webhook signature and
   * deduplicate event IDs before changing financial state.
   */
  try {
    const eventId = req.header("x-pagarme-event-id") || req.body?.id;
    if (!eventId) return res.status(400).json({ ok: false });

    db.prepare(`
      CREATE TABLE IF NOT EXISTS payment_webhook_events (
        event_id TEXT PRIMARY KEY,
        provider TEXT NOT NULL,
        payload TEXT NOT NULL,
        created_at INTEGER NOT NULL
      )
    `);

    const exists = db.prepare(
      "SELECT event_id FROM payment_webhook_events WHERE event_id=?"
    ).get(String(eventId));

    if (exists) return res.status(204).end();

    db.prepare(`
      INSERT INTO payment_webhook_events(event_id,provider,payload,created_at)
      VALUES (?,?,?,?)
    `).run(
      String(eventId),
      "pagarme",
      JSON.stringify(req.body || {}),
      now()
    );

    /*
     * Map provider transfer status to the internal withdrawal state.
     * The exact event names must be confirmed against the current
     * Pagar.me account/API contract before production.
     */
    const transfer = req.body?.data || req.body?.transfer || {};
    const transferId = transfer.id;
    const providerStatus = String(
      transfer.status || req.body?.status || ""
    ).toLowerCase();

    if (transferId) {
      let status = null;
      if (["paid", "transferred", "succeeded", "success"].includes(providerStatus)) {
        status = "paid";
      } else if (["failed", "canceled", "cancelled"].includes(providerStatus)) {
        status = "failed";
      }

      if (status) {
        db.prepare(`
          UPDATE creator_withdrawals
          SET status=?, updated_at=?
          WHERE payment_reference=? AND status='processing'
        `).run(status, now(), String(transferId));
      }
    }

    res.status(204).end();
  } catch (error) {
    console.error("Pagar.me webhook:", error);
    res.status(500).json({ ok: false });
  }
});


/* =========================
   V60 — KYC + RECEBEDOR
   ========================= */

async function createPagarmeRecipient(registerInformation, externalCode) {
  return pagarmeRequest("/recipients", "POST", {
    code: externalCode,
    register_information: registerInformation
  });
}

async function createPagarmeKycLink(recipientId) {
  return pagarmeRequest(`/recipients/${encodeURIComponent(recipientId)}/kyc_link`, "POST");
}

async function getPagarmeRecipient(recipientId) {
  return pagarmeRequest(`/recipients/${encodeURIComponent(recipientId)}`, "GET");
}

app.post("/v1/creator/payout-profile", async (req, res) => {
  try {
    const { creatorId, registerInformation } = req.body ?? {};

    if (!creatorId || !registerInformation || typeof registerInformation !== "object") {
      return res.status(400).json({
        ok: false,
        error: "creatorId e registerInformation são obrigatórios."
      });
    }

    const existing = db.prepare(
      "SELECT recipient_id, kyc_status FROM creator_payout_profiles WHERE creator_id=?"
    ).get(creatorId);

    if (existing) {
      return res.json({
        ok: true,
        status: existing.kyc_status,
        recipientId: existing.recipient_id,
        message: "Perfil de recebimento já cadastrado."
      });
    }

    /*
     * registerInformation must be assembled server-side from validated
     * onboarding data. Never trust arbitrary financial fields from a
     * public client without authentication and validation.
     */
    const recipient = await createPagarmeRecipient(
      registerInformation,
      `creator_${creatorId}`
    );

    const recipientId = recipient.id;
    if (!recipientId) {
      throw new Error("Pagar.me não retornou recipient_id.");
    }

    const timestamp = now();

    db.prepare(`
      INSERT INTO creator_payout_profiles
        (creator_id,recipient_id,kyc_status,created_at,updated_at)
      VALUES (?,?,?,?,?)
    `).run(
      creatorId,
      recipientId,
      String(recipient.status || "registration"),
      timestamp,
      timestamp
    );

    res.status(201).json({
      ok: true,
      recipientId,
      status: recipient.status || "registration",
      kyc: recipient.kyc_details || null
    });
  } catch (error) {
    res.status(502).json({
      ok: false,
      error: error.message || "Falha ao criar recebedor."
    });
  }
});

app.get("/v1/creator/:creatorId/payout-profile", async (req, res) => {
  try {
    const profile = db.prepare(`
      SELECT creator_id, recipient_id, kyc_status, created_at, updated_at
      FROM creator_payout_profiles
      WHERE creator_id=?
    `).get(req.params.creatorId);

    if (!profile) {
      return res.status(404).json({
        ok: false,
        error: "Perfil de recebimento não encontrado."
      });
    }

    const recipient = await getPagarmeRecipient(profile.recipient_id);

    res.json({
      ok: true,
      creatorId: profile.creator_id,
      recipientId: profile.recipient_id,
      status: recipient.status || profile.kyc_status,
      kyc: recipient.kyc_details || null
    });
  } catch (error) {
    res.status(502).json({
      ok: false,
      error: error.message || "Falha ao consultar recebedor."
    });
  }
});

app.post("/v1/creator/:creatorId/payout-profile/kyc-link", async (req, res) => {
  try {
    const profile = db.prepare(
      "SELECT recipient_id, kyc_status FROM creator_payout_profiles WHERE creator_id=?"
    ).get(req.params.creatorId);

    if (!profile) {
      return res.status(404).json({
        ok: false,
        error: "Crie o perfil de recebimento antes do KYC."
      });
    }

    const recipient = await getPagarmeRecipient(profile.recipient_id);

    /*
     * The current Pagar.me KYC flow exposes the link when the recipient
     * is ready for proof of life. We avoid issuing a link blindly.
     */
    const kycStatus = recipient.kyc_details?.status;
    const recipientStatus = recipient.status;

    if (
      recipientStatus !== "affiliation" &&
      kycStatus !== "partially_denied"
    ) {
      return res.status(409).json({
        ok: false,
        error: "O recebedor ainda não está no estágio de KYC que exige link.",
        recipientStatus,
        kycStatus: kycStatus || null
      });
    }

    const link = await createPagarmeKycLink(profile.recipient_id);

    res.json({
      ok: true,
      recipientId: profile.recipient_id,
      url: link.url || null,
      base64: link.base64 || null,
      expirationDate: link.expiration_date || null
    });
  } catch (error) {
    res.status(502).json({
      ok: false,
      error: error.message || "Falha ao criar link de KYC."
    });
  }
});

/*
 * Extend the provider webhook so recipient.updated changes the internal
 * payout profile. The existing Pagar.me webhook endpoint remains idempotent.
 */

app.post("/v1/webhooks/pagarme/recipient", async (req, res) => {
  try {
    const eventId = req.header("x-pagarme-event-id") || req.body?.id;
    if (!eventId) return res.status(400).json({ ok: false });

    db.prepare(`
      CREATE TABLE IF NOT EXISTS payment_webhook_events (
        event_id TEXT PRIMARY KEY,
        provider TEXT NOT NULL,
        payload TEXT NOT NULL,
        created_at INTEGER NOT NULL
      )
    `);

    const exists = db.prepare(
      "SELECT event_id FROM payment_webhook_events WHERE event_id=?"
    ).get(String(eventId));

    if (exists) return res.status(204).end();

    db.prepare(`
      INSERT INTO payment_webhook_events(event_id,provider,payload,created_at)
      VALUES (?,?,?,?)
    `).run(
      String(eventId),
      "pagarme",
      JSON.stringify(req.body || {}),
      now()
    );

    const data = req.body?.data || req.body?.recipient || {};
    const recipientId = data.id || data.recipient_id;

    if (recipientId) {
      const status = String(data.status || "unknown");
      db.prepare(`
        UPDATE creator_payout_profiles
        SET kyc_status=?, updated_at=?
        WHERE recipient_id=?
      `).run(status, now(), String(recipientId));
    }

    res.status(204).end();
  } catch (error) {
    console.error("Pagar.me recipient webhook:", error);
    res.status(500).json({ ok: false });
  }
});


/* =========================
   V61 — STATUS KYC DO CRIADOR
   ========================= */

function normalizeKycStatus(profile, recipient) {
  const recipientStatus = String(recipient?.status || profile?.kyc_status || "");
  const kycStatus = String(recipient?.kyc_details?.status || "");
  const reason = String(recipient?.kyc_details?.status_reason || "");

  if (recipientStatus === "active" && kycStatus === "approved") {
    return { code: "approved", label: "Aprovado", canWithdraw: true };
  }

  if (recipientStatus === "refused" || kycStatus === "denied") {
    return { code: "rejected", label: "Reprovado", canWithdraw: false };
  }

  if (
    recipientStatus === "affiliation" &&
    kycStatus === "partially_denied" &&
    reason === "additional_documents_required"
  ) {
    return { code: "action_required", label: "Ação necessária", canWithdraw: false };
  }

  if (
    kycStatus === "pending" ||
    recipientStatus === "registration" ||
    recipientStatus === "affiliation"
  ) {
    return { code: "pending", label: "Aguardando aprovação", canWithdraw: false };
  }

  return { code: "pending", label: "Aguardando análise", canWithdraw: false };
}

app.get("/v1/creator/:creatorId/kyc-status", async (req, res) => {
  try {
    const profile = db.prepare(`
      SELECT creator_id, recipient_id, kyc_status, created_at, updated_at
      FROM creator_payout_profiles
      WHERE creator_id=?
    `).get(req.params.creatorId);

    if (!profile) {
      return res.json({
        ok: true,
        registered: false,
        status: {
          code: "not_started",
          label: "Cadastro não iniciado",
          canWithdraw: false
        }
      });
    }

    const recipient = await getPagarmeRecipient(profile.recipient_id);
    const status = normalizeKycStatus(profile, recipient);

    res.json({
      ok: true,
      registered: true,
      creatorId: profile.creator_id,
      recipientId: profile.recipient_id,
      status,
      recipientStatus: recipient.status || null,
      kyc: recipient.kyc_details || null,
      updatedAt: profile.updated_at
    });
  } catch (error) {
    res.status(502).json({
      ok: false,
      error: error.message || "Não foi possível consultar o status do KYC."
    });
  }
});


/* V62 — BLOQUEIO DE SAQUE POR KYC */
async function getCreatorPayoutEligibility(creatorId) {
  const profile = db.prepare(`
    SELECT creator_id, recipient_id, kyc_status
    FROM creator_payout_profiles WHERE creator_id=?
  `).get(creatorId);

  if (!profile) return {
    eligible: false, code: "kyc_not_started",
    message: "Conclua o cadastro de recebimento antes de solicitar saque."
  };

  try {
    const recipient = await getPagarmeRecipient(profile.recipient_id);
    const recipientStatus = String(recipient?.status || "");
    const kycStatus = String(recipient?.kyc_details?.status || "");

    if (recipientStatus === "active" && kycStatus === "approved") {
      return { eligible: true, code: "approved",
        message: "Cadastro aprovado para movimentação." };
    }

    if (recipientStatus === "refused" || kycStatus === "denied") {
      return { eligible: false, code: "kyc_rejected",
        message: "Seu cadastro de recebimento não foi aprovado." };
    }

    return { eligible: false, code: "kyc_pending",
      message: "Seu cadastro de recebimento ainda está em análise." };
  } catch {
    return { eligible: false, code: "provider_unavailable",
      message: "Não foi possível validar seu cadastro agora." };
  }
}

app.get("/v1/creator/:creatorId/payout-eligibility", async (req, res) => {
  const result = await getCreatorPayoutEligibility(req.params.creatorId);
  res.json({ ok: true, ...result });
});

app.get("/health", (_req, res) => {
  res.json({
    ok: true,
    service: "conecta-vence-v53",
    googleConfigured: Boolean(process.env.GOOGLE_SERVICE_ACCOUNT_JSON)
  });
});

app.get("/v1/wallet/:userId", (req, res) => {
  res.json({
    userId: req.params.userId,
    coins: getBalance(req.params.userId)
  });
});

app.post("/v1/billing/validate-and-credit", async (req, res) => {
  try {
    const { userId, productId, purchaseToken } = req.body ?? {};

    if (!userId || !productId || !purchaseToken) {
      return res.status(400).json({
        ok: false,
        error: "userId, productId e purchaseToken são obrigatórios."
      });
    }

    if (!PRODUCTS[productId]) {
      return res.status(400).json({
        ok: false,
        error: "Product ID não cadastrado."
      });
    }

    const existing = db.prepare(
      "SELECT status FROM purchases WHERE purchase_token = ?"
    ).get(purchaseToken);

    if (existing?.status === "credited") {
      return res.json({
        ok: true,
        status: "already_processed",
        coins: getBalance(userId)
      });
    }

    const verification = await getGooglePurchase(productId, purchaseToken);

    if (!verification.configured) {
      return res.status(503).json({
        ok: false,
        status: "google_not_configured"
      });
    }

    if (!verification.verified) {
      return res.status(202).json({
        ok: false,
        status: "pending"
      });
    }

    const result = await processVerifiedPurchase({
      userId,
      productId,
      purchaseToken,
      orderId: verification.orderId
    });

    return res.json({
      ok: true,
      status: result.credited ? "credited" : "already_processed",
      coins: result.balance,
      orderId: verification.orderId
    });
  } catch (error) {
    console.error(error);
    return res.status(502).json({
      ok: false,
      error: "Falha ao validar/processar compra."
    });
  }
});

app.post("/v1/rtdn/pubsub", async (req, res) => {
  try {
    const message = req.body?.message;
    const messageId = message?.messageId || message?.message_id;

    if (!messageId) {
      return res.status(400).json({ ok: false, error: "messageId ausente." });
    }

    const duplicate = db.prepare(
      "SELECT message_id FROM rtdn_messages WHERE message_id = ?"
    ).get(messageId);

    if (duplicate) return res.status(204).end();

    const event = message.data
      ? JSON.parse(Buffer.from(message.data, "base64").toString("utf8"))
      : {};

    const otp = event.oneTimeProductNotification;
    const type = otp
      ? `one_time_${otp.notificationType}`
      : event.voidedPurchaseNotification
        ? "voided_purchase"
        : event.testNotification
          ? "test"
          : "other";

    const token =
      otp?.purchaseToken ||
      event.voidedPurchaseNotification?.purchaseToken ||
      null;

    db.prepare(`
      INSERT INTO rtdn_messages(message_id,event_type,purchase_token,created_at)
      VALUES (?,?,?,?)
    `).run(messageId, type, token, now());

    /*
     * RTDN is a signal, not the source of truth.
     * The worker should use purchaseToken + product ID to query
     * Google Play and then apply the appropriate idempotent transition.
     */
    return res.status(204).end();
  } catch (error) {
    console.error(error);
    return res.status(500).json({ ok: false, error: "Falha no RTDN." });
  }
});

app.listen(PORT, () => {
  console.log(`Conecta & Vence V53 listening on ${PORT}`);
});
