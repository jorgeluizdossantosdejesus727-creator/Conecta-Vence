package com.conectaevencer

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

data class CoinPackage(
    val productId: String,
    val coins: Long,
    val priceCents: Long
)

class PurchaseRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    /*
     * O cliente registra somente a intenção/dados mínimos da compra.
     * O crédito definitivo das moedas deve ocorrer no backend após validação
     * do purchaseToken junto ao Google Play.
     */
    fun registerPurchaseForValidation(
        productId: String,
        purchaseToken: String,
        onResult: (Boolean, String?) -> Unit
    ) {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            onResult(false, "Usuário não autenticado.")
            return
        }
        if (productId.isBlank() || purchaseToken.isBlank()) {
            onResult(false, "Dados da compra inválidos.")
            return
        }

        val purchase = mapOf(
            "userId" to uid,
            "productId" to productId,
            "purchaseToken" to purchaseToken,
            "status" to "pending_validation",
            "createdAt" to System.currentTimeMillis()
        )

        db.collection("purchaseValidations")
            .add(purchase)
            .addOnSuccessListener {
                onResult(true, null)
            }
            .addOnFailureListener {
                onResult(false, it.message)
            }
    }
}
