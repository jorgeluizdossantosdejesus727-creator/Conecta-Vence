# V57 — Interface visual do painel administrativo

Abra `index.html` em um navegador após iniciar o backend da V56/V57.

Por padrão, a interface usa:
- API: `http://localhost:8080`
- chave: valor de `localStorage.cv_admin_key`

Para configurar no navegador:
```js
localStorage.setItem("cv_api_base", "https://SEU-DOMINIO");
localStorage.setItem("cv_admin_key", "SUA_CHAVE");
location.reload();
```

Antes de produção:
- usar HTTPS;
- não distribuir a chave administrativa no código-fonte;
- trocar a chave simples por autenticação administrativa robusta;
- restringir CORS;
- registrar auditoria;
- proteger contra CSRF e abuso conforme a arquitetura de autenticação adotada.
