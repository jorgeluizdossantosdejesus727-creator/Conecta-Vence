package com.conectaevencer

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query

data class PostItem(
    val id: String,
    val authorId: String,
    val text: String,
    val createdAt: Long
)

data class MessageItem(
    val id: String,
    val senderId: String,
    val recipientId: String,
    val text: String,
    val createdAt: Long
)

class RealtimeSocialRepository {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    fun listenPosts(
        onChange: (List<PostItem>) -> Unit,
        onError: (String) -> Unit
    ): ListenerRegistration {
        return db.collection("posts")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onError(error.message ?: "Erro no feed.")
                    return@addSnapshotListener
                }
                val posts = snapshot?.documents?.mapNotNull { d ->
                    val data = d.data ?: return@mapNotNull null
                    PostItem(
                        id = d.id,
                        authorId = data["authorId"] as? String ?: "",
                        text = data["text"] as? String ?: "",
                        createdAt = (data["createdAt"] as? Number)?.toLong() ?: 0L
                    )
                } ?: emptyList()
                onChange(posts)
            }
    }

    fun listenMessages(
        recipientId: String,
        onChange: (List<MessageItem>) -> Unit,
        onError: (String) -> Unit
    ): ListenerRegistration {
        val senderId = auth.currentUser?.uid
        if (senderId == null) {
            onError("Usuário não autenticado.")
            return db.collection("noop").addSnapshotListener { _, _ -> }
        }

        return db.collection("conversations")
            .document("${senderId}_$recipientId")
            .collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onError(error.message ?: "Erro nas mensagens.")
                    return@addSnapshotListener
                }
                val messages = snapshot?.documents?.mapNotNull { d ->
                    val data = d.data ?: return@mapNotNull null
                    MessageItem(
                        id = d.id,
                        senderId = data["senderId"] as? String ?: "",
                        recipientId = data["recipientId"] as? String ?: "",
                        text = data["text"] as? String ?: "",
                        createdAt = (data["createdAt"] as? Number)?.toLong() ?: 0L
                    )
                } ?: emptyList()
                onChange(messages)
            }
    }
}
