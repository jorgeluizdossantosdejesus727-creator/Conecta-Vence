# V50 — Backend de validação de compras

Este backend é a base do servidor do Conecta & Vence.

## Fluxo

1. O aplicativo recebe o `purchaseToken`.
2. O app envia `userId`, `productId` e `purchaseToken` ao backend.
3. O backend autentica/autorização do usuário.
4. O backend consulta a Google Play Developer API.
5. Só compra `PURCHASED` e válida recebe crédito.
6. O token é protegido contra processamento duplicado.
7. O backend registra a transação/ledger.
8. O backend confirma ou consome a compra conforme o tipo de produto.

## Antes de produção

- Configurar Google Cloud/Google Play Developer API.
- Usar credenciais somente no servidor.
- Implementar autenticação real do usuário no endpoint.
- Persistir tokens/transações em banco com índice único.
- Mapear cada Product ID para uma quantidade fixa de moedas.
- Implementar confirmação/consumo pelo backend.
- Implementar RTDN para sincronizar mudanças de estado.
- Adicionar logs, auditoria, rate limiting e monitoramento.
- Testar compras pendentes, reembolsos, compras repetidas e falhas de rede.

O endpoint deliberadamente não credita moedas enquanto a validação Google Play não estiver configurada.
