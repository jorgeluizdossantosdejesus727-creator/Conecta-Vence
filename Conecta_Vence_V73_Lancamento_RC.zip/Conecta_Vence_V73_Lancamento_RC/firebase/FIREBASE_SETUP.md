# V26 — Firebase Authentication

A V26 substitui o conceito de conta local por autenticação Firebase.

Para ativar:
1. Criar/abrir o projeto no Firebase Console.
2. Adicionar o aplicativo Android com o mesmo applicationId.
3. Baixar `google-services.json`.
4. Colocar esse arquivo dentro do módulo `app/`.
5. Ativar Authentication > Sign-in method > Email/Password.
6. Adicionar Firebase Authentication ao Gradle usando o Firebase Android BoM.
7. Fazer o build e testar cadastro/login.

O Firebase oferece `createUserWithEmailAndPassword` e
`signInWithEmailAndPassword` para contas com e-mail e senha. Consulte a
documentação oficial antes de publicar.

IMPORTANTE:
- Não inventar `google-services.json`.
- Não colocar credenciais de servidor no APK.
- A senha deve ser tratada pelo Firebase Authentication, não armazenada em
  localStorage ou em uma coleção própria.
