# V35 — Checklist para teste fechado

## Build
- [ ] Definir applicationId definitivo
- [ ] Definir versionCode/versionName
- [ ] Gerar build release
- [ ] Assinar o AAB com chave segura
- [ ] Confirmar que credenciais privadas não estão no APK/AAB

## Firebase
- [ ] Adicionar google-services.json real
- [ ] Ativar Authentication
- [ ] Publicar regras Firestore revisadas
- [ ] Configurar backend real

## Google Play
- [ ] Criar produtos de moedas
- [ ] Configurar testers
- [ ] Criar faixa de teste fechado
- [ ] Enviar AAB
- [ ] Aguardar processamento

## Testes
- [ ] Cadastro e login
- [ ] Perfil
- [ ] Publicações
- [ ] Conversas
- [ ] Fazendinha
- [ ] Carteira
- [ ] Presentes
- [ ] Ganhos
- [ ] Saque
- [ ] Compra de teste
- [ ] Reembolso/cancelamento
- [ ] Segurança

## Aprovação
- [ ] Nenhum bug crítico
- [ ] Nenhuma duplicação de saldo
- [ ] Nenhuma falha crítica de autenticação
- [ ] Nenhum saldo financeiro controlado apenas pelo cliente
