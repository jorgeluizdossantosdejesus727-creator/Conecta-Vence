package com.conectaevencer.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

data class CloudWallet(
    val beans: Long = 0,
    val diamonds: Long = 0,
    val giftsSent: Long = 0,
    val earningsCents: Long = 0
)

class CloudWalletSync(
    private val onWalletChanged: (CloudWallet) -> Unit,
    private val onError: (String) -> Unit
) {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private var listener: ListenerRegistration? = null

    fun start() {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            onError("Usuário não autenticado.")
            return
        }

        listener?.remove()
        listener = db.collection("users").document(uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    onError(error.message ?: "Erro de sincronização.")
                    return@addSnapshotListener
                }

                val data = snapshot?.data ?: emptyMap()
                onWalletChanged(
                    CloudWallet(
                        beans = (data["beans"] as? Number)?.toLong() ?: 0,
                        diamonds = (data["diamonds"] as? Number)?.toLong() ?: 0,
                        giftsSent = (data["giftsSent"] as? Number)?.toLong() ?: 0,
                        earningsCents = (data["earningsCents"] as? Number)?.toLong() ?: 0
                    )
                )
            }
    }

    fun stop() {
        listener?.remove()
        listener = null
    }
}
